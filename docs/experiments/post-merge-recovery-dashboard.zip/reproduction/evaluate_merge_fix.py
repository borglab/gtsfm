import json
from pathlib import Path
import runpy
from gtsfm.loader.olsson_loader import OlssonLoader

helper=runpy.run_path('/tmp/gtsfm-sift-five/scripts/evaluate_sift_comparison.py')
evaluate,read_poses=helper['evaluate'],helper['read_poses']
root=Path('/tmp/gtsfm-merge-fix-results')
summary={}
for record_path in sorted(root.glob('*/*.execution.json')):
 record=json.loads(record_path.read_text())
 if record.get('returncode') != 0:
  continue
 name,method=record['dataset'],record['method']
 command=record['command']
 dataset=Path(command[command.index('--dataset_dir')+1])
 if command[command.index('--loader')+1]=='olsson':
  loader=OlssonLoader(str(dataset))
  reference={Path(n).name:loader.get_camera_pose(i) for i,n in enumerate(loader.image_filenames())}
 else:
  reference=read_poses(dataset)
 stages={}
 for label,output in [('before',Path(record['previous_results'])/method),('after',root/name/method)]:
  if label=='before' and method=='rootsift_legacy':
   stages[label]={'status':'failed: GTSAM input stream error during deserialization'}
   continue
  stages[label]={}
  for stage in ['ba_output','merged_retriangulated']:
   model=output/'results'/stage
   score={k:v for k,v in evaluate(reference,read_poses(model)).items() if k!='pair_errors'}
   score['tracks']=sum(1 for line in (model/'points3D.txt').read_text().splitlines() if line and not line.startswith('#'))
   stages[label][stage]=score
 summary[f'{name}/{method}']=stages
 print(name,method,{label:{s:(v['auc_percent']['5.0'],v['registered_images'],v['tracks']) for s,v in stages[label].items() if isinstance(v,dict)} for label in stages},flush=True)
(root/'full-reference-comparison.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
