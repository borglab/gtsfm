"""RootSIFT descriptor implementation.

This descriptor was proposed in 'Three things everyone should know to improve object retrieval' and is build upon
OpenCV's API.

Note: this is a standalone descriptor.

References:
- https://www.robots.ox.ac.uk/~vgg/publications/2012/Arandjelovic12/arandjelovic12.pdf
- https://docs.opencv.org/3.4.2/d5/d3c/classcv_1_1xfeatures2d_1_1SIFT.html

Authors: Ayush Baid
"""
import numpy as np

from gtsfm.common.image import Image
from gtsfm.common.keypoints import Keypoints
from gtsfm.frontend.descriptor.sift import SIFTDescriptor


class RootSIFTDescriptor(SIFTDescriptor):
    """RootSIFT descriptor using OpenCV's implementation."""

    def describe(self, image: Image, keypoints: Keypoints) -> np.ndarray:
        """Assign descriptors to detected features in an image.

        Note: Each descriptor will have unit L2-norm, as L1-normalization followed by a square root already gives unit
        norm under the L2 norm.

        Arguments:
            image: the input image.
            keypoints: the keypoints to describe, of length N.

        Returns:
            Descriptors for the input features, of shape (N, D) where D is the dimension of each descriptor.
        """
        if len(keypoints) == 0:
            return np.array([])

        sift_desc = super().describe(image, keypoints)

        # Step 1: L1 normalization
        l1_norms = np.sum(sift_desc, axis=1, keepdims=True)
        sift_desc = sift_desc / (l1_norms + np.finfo(float).eps)

        # Step 2: Element wise square-root
        sift_desc = np.sqrt(sift_desc)

        return sift_desc


from gtsfm.frontend.detector_descriptor.sift import SIFTDetectorDescriptor

class LegacyRootSIFTDetectorDescriptor(SIFTDetectorDescriptor):
    def detect_and_describe(self, image):
        keypoints, _ = super().detect_and_describe(image)
        return keypoints, RootSIFTDescriptor().describe(image, keypoints).astype(np.float32)


"""Bounded rotation averaging for controlled benchmark experiments.

This retains Shonan's rank-three objective and chordal initialization, but does
not attempt a global-optimality certificate. It is not a production setting.
"""

from typing import List, Optional

import gtsam
from gtsam import Rot3

from gtsfm.averaging.rotation.shonan import ShonanRotationAveraging


class UncertifiedRotationAveraging(ShonanRotationAveraging):
    """Solve Shonan's rank-three problem without optimality certification."""

    def _run_with_consecutive_ordering(
        self, num_connected_nodes: int, measurements: gtsam.BinaryMeasurementsRot3
    ) -> List[Optional[Rot3]]:
        """Estimate rotations for a connected, consecutively numbered graph.

        Args:
            num_connected_nodes: Number of cameras in the connected graph.
            measurements: Relative rotation measurements.

        Returns:
            Estimated rotations in camera-index order.
        """
        parameters = gtsam.ShonanAveragingParameters3(gtsam.LevenbergMarquardtParams.CeresDefaults())
        parameters.setUseHuber(False)
        parameters.setCertifyOptimality(False)
        parameters.setGaugesWeight(0.0)
        parameters.setKarcherWeight(0.0)
        parameters.setAnchorWeight(1.0)
        parameters.setAnchor(measurements[0].key1(), Rot3())
        solver = gtsam.ShonanAveraging3(measurements, parameters)
        result, _ = solver.run(self.chordal_initialize(measurements), 3, 3)
        return [result.atRot3(i) if result.exists(i) else None for i in range(num_connected_nodes)]
