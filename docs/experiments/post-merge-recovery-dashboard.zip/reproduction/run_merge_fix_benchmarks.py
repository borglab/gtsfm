"""Rerun only affected scenes with the production RootSIFT implementation."""
import concurrent.futures
import json
import os
from pathlib import Path
import subprocess
import time

repo=Path('/tmp/gtsfm-preserve-ba-calibration')
out=Path('/tmp/gtsfm-merge-fix-results')
out.mkdir(exist_ok=True)
trials=[
 ('door','/tmp/gtsfm-sift-door-comparison','rootsift'),
 ('astrovision','/tmp/gtsfm-sift-five-results/astrovision','rootsift'),
 ('gerrard','/tmp/gtsfm-sift-gerrard-fixed-rank','rootsift'),
 ('palace','/tmp/gtsfm-sift-five-results/palace','rootsift'),
 ('skydio32','/tmp/gtsfm-sift-skydio32-comparison','rootsift'),
 ('skydio32','/tmp/gtsfm-sift-skydio32-comparison','rootsift_legacy'),
]
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
paths=[str(repo),'/tmp','/home/dellaert/git/gtsfm/thirdparty/vggt','/home/dellaert/git/gtsfm/thirdparty/LightGlue','/home/dellaert/git/gtsfm/thirdparty/AnySplat']
env=dict(os.environ,PYTHONPATH=':'.join(paths),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
def run(trial):
 name,previous,method=trial
 dest=out/name/method
 assert not dest.exists(),dest
 record=json.loads((Path(previous)/f'{method}.execution.json').read_text())
 cmd=record['command']
 cmd[1]=str(repo/'gtsfm/runner.py')
 cmd[cmd.index('--output_root')+1]=str(dest)
 # Preserve every dataset, retrieval, verifier, and solver setting from the original trial.
 for i,arg in enumerate(cmd):
  if 'scripts.benchmark_sift_variants.NormalizedRootSIFTDetectorDescriptor' in arg:
   cmd[i]=arg.replace('scripts.benchmark_sift_variants.NormalizedRootSIFTDetectorDescriptor','gtsfm.frontend.detector_descriptor.rootsift.RootSIFTDetectorDescriptor')
  if 'scripts.benchmark_sift_variants.LegacyRootSIFTDetectorDescriptor' in arg:
   cmd[i]=arg.replace('scripts.benchmark_sift_variants.LegacyRootSIFTDetectorDescriptor','merge_benchmark_support.LegacyRootSIFTDetectorDescriptor')
  if 'scripts.benchmark_rotation_averaging.UncertifiedRotationAveraging' in arg:
   cmd[i]=arg.replace('scripts.benchmark_rotation_averaging.UncertifiedRotationAveraging','merge_benchmark_support.UncertifiedRotationAveraging')
 dest.parent.mkdir(exist_ok=True)
 execution={'dataset':name,'method':method,'code_commit':commit,'previous_results':previous,'command':cmd,'PYTHONPATH':env['PYTHONPATH']}
 rp=dest.parent/f'{method}.execution.json'
 rp.write_text(json.dumps(execution,indent=2)+'\n')
 print('START',name,method,flush=True)
 start=time.monotonic()
 with (dest.parent/f'{method}.log').open('w') as log:
  process=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 execution.update(returncode=process.returncode,wall_seconds=time.monotonic()-start)
 rp.write_text(json.dumps(execution,indent=2)+'\n')
 print('DONE',name,method,execution['returncode'],round(execution['wall_seconds'],1),flush=True)
 return execution
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
 records=list(executor.map(run,trials))
(out/'executions.json').write_text(json.dumps(records,indent=2)+'\n')
if any(r['returncode'] for r in records):
 raise SystemExit(1)
