STANDARD GTSFM BENCHMARK DASHBOARDS — EIGHT SCENES

Generated with the unchanged gtsfm/evaluation/visualize_benchmark_comparison.py
from saved original HTML reports. Only the temporary workflow matrix and artifact
layout were adapted to the local datasets. See sources.json for all input paths
and any omitted scene without a final report.

Open the HTML files in a browser. Internet access is needed for Plotly's CDN.
Hover labels Master/Branch mean baseline extractor/OpenCV plus RootSIFT.

standard-rootsift-vs-opencv.html compares against plain OpenCV SIFT.
standard-rootsift-vs-rootsift_legacy.html compares against old standalone RootSIFT.
The old Skydio-32 run failed and has no final report, so it is omitted.

These stock dashboards retain original pipeline scores, including uncorrected
Skydio-32 OpenCV pose-AUC denominators and constructed-camera-only scores. Use the
custom chart and opencv-rootsift.md for corrected full-reference pose AUC.
The stock tool excludes the later post-merge BA section. Runtime differences are
not controlled: cache reuse and concurrent machine workloads differ.

Original Door/Skydio-32/Gerrard runs use lookahead 10; five new scenes use 15.
All three extractors share settings within each scene. Notre Dame's reference
model registers 19 images out of 20 files and uses separate intrinsics.
Gerrard Hall, South Building and Palace use rank-three Shonan without certification.
Skydio, Notre Dame, Gerrard and South Building references are COLMAP reconstructions.
Palace uses Olsson data.mat; AstroVision uses its supplied reference model.
All runs use GTSFM base 8f21351c. Plot settings and direction heuristics are stock.
