"""Class to hold the tracks and cameras of a 3D scene.
This can be the output of either data association or of bundle adjustment.

Authors: Ayush Baid, John Lambert, Xiaolong Wu
"""

import itertools
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple, Union

import gtsam  # type: ignore
import numpy as np
from numpy.typing import NDArray
from gtsam import Pose3, SfmTrack, Similarity3, Values
from gtsam.symbol_shorthand import K, P, X  # type: ignore

import gtsfm.common.types as gtsfm_types
import gtsfm.utils.graph as graph_utils
import gtsfm.utils.images as image_utils
import gtsfm.utils.io as io_utils
import gtsfm.utils.logger as logger_utils
import gtsfm.utils.reprojection as reprojection
import thirdparty.colmap.scripts.python.read_write_model as colmap_io
from gtsfm.common.image import Image
from gtsfm.evaluation.metrics import GtsfmMetric
from gtsfm.products.visibility_graph import ImageIndexPairs
from gtsfm.utils import align, transform
from gtsfm.utils.pycolmap_utils import gtsfm_calibration_to_colmap_camera
from gtsfm.utils.splat import GaussiansProtocol, merge_gaussian_splats
from gtsfm.utils.transform import transform_gaussian_splats

logger = logger_utils.get_logger()

EQUALITY_TOLERANCE = 1e-5

GaussianSplatsType = Union[dict[str, Any], GaussiansProtocol]


@dataclass
class ImageInfo:
    """Metadata describing an image associated with a camera index."""

    name: Optional[str] = None
    shape: Optional[tuple[int, ...]] = None


def get_average_calibration(
    initial_data: "GtsfmData", camera_indices: Optional[List[int]] = None
) -> gtsfm_types.CALIBRATION_TYPE:
    """Get the average calibration from the cameras."""
    calibration_vectors = []
    calib_cls = None
    cam_indices = camera_indices if camera_indices is not None else initial_data.get_valid_camera_indices()

    def to_cal_vector(c: gtsfm_types.CALIBRATION_TYPE) -> np.ndarray:
        if isinstance(c, gtsam.Cal3Bundler):
            return np.array([c.fx(), c.k1(), c.k2(), c.px(), c.py()])
        else:
            return c.vector()

    for i in cam_indices:
        camera_cal = initial_data.get_camera(i).calibration()
        if calib_cls is None:
            calib_cls = type(camera_cal)
        calibration_vectors.append(to_cal_vector(camera_cal))
    average_calibration_vector = np.mean(calibration_vectors, axis=0)
    if calib_cls == gtsam.Cal3Bundler:
        # Cal3Bundler expects the parameters in the order: fx, k1, k2, px, py, no vector constructor.
        return calib_cls(*average_calibration_vector.tolist())  # type: ignore
    else:
        return calib_cls(average_calibration_vector)  # type: ignore


class GtsfmData:
    """Class containing cameras and tracks, essentially describing the complete 3D scene.

    This class is needed over GTSAM's SfmData type because GTSAM's type does not allow for non-contiguous cameras.
    The situation of non-contiguous cameras can exists because of failures in front-end.
    """

    def __init__(
        self,
        number_images: int,
        cameras: Optional[Mapping[int, gtsfm_types.CAMERA_TYPE]] = None,
        tracks: Optional[List[SfmTrack]] = None,
        gaussian_splats: Optional[GaussianSplatsType] = None,
        pose_covariances: Optional[Mapping[int, NDArray[np.float64]]] = None,
    ) -> None:
        """Initializes the class.

        Args:
            number_images: number of images/cameras in the scene.
            cameras: Cameras in scene.
            tracks: SfmTracks in scene.
        """
        self._number_images = number_images
        self._cameras: dict[int, gtsfm_types.CAMERA_TYPE] = {}
        self._tracks: List[SfmTrack] = []
        self._image_info: dict[int, ImageInfo] = {}
        self._gaussian_splats: GaussianSplatsType | None = None
        self._camera_to_measurement_map: dict[int, list[tuple[int, int]]] | None = None
        self._pose_covariances: dict[int, NDArray[np.float64]] = {}

        # Initialize from inputs if provided.
        if cameras is not None:
            for i, cam in cameras.items():
                self.add_camera(i, cam)
        if tracks is not None:
            for track in tracks:
                self.add_track(track)
        if gaussian_splats is not None:
            self.set_gaussian_splats(gaussian_splats)
        if pose_covariances is not None:
            self.set_camera_pose_covariances(pose_covariances)

    def __repr__(self) -> str:
        """String representation of the object."""
        return (
            f"GtsfmData("
            f"num_images={self._number_images}, "
            f"num_cameras={len(self._cameras)}, "
            f"num_tracks={len(self._tracks)})"
        )

    def has_gaussian_splats(self) -> bool:
        """Return True if Gaussian splats have been attached."""
        return self._gaussian_splats is not None

    def get_gaussian_splats(self) -> Optional[GaussianSplatsType]:
        """Return the stored Gaussian splats, if any."""
        return self._gaussian_splats

    def set_gaussian_splats(self, gaussian_splats: Optional[GaussianSplatsType]) -> None:
        """Attach Gaussian splats to the scene."""
        self._gaussian_splats = gaussian_splats

    @classmethod
    def from_sfm_data(cls, sfm_data: gtsam.SfmData) -> "GtsfmData":
        """Initialize from gtsam.SfmData instance.

        Args:
            sfm_data: camera parameters and point tracks.

        Returns:
            A new GtsfmData instance.
        """
        num_images = sfm_data.numberCameras()
        gtsfm_data = cls(num_images)
        for i in range(num_images):
            camera = sfm_data.camera(i)
            gtsfm_data.add_camera(i, camera)
        for j in range(sfm_data.numberTracks()):
            gtsfm_data.add_track(sfm_data.track(j))

        return gtsfm_data

    @classmethod
    def read_colmap(cls, data_dir: str) -> "GtsfmData":
        """Reads in full scene reconstruction model from scene data stored in the COLMAP file format.

        Reference: https://colmap.github.io/format.html

        Args:
            data_dir: This directory should contain 3 files: either `cameras.txt`, `images.txt`, and `points3D.txt`, or
                `cameras.bin`, `images.bin`, and `points3D.bin`.

        Returns:
            A new GtsfmData instance.
        """
        # Determine whether scene data is stored in a text (txt) or binary (bin) file format.
        if Path(data_dir, "images.txt").exists():
            file_format = ".txt"
        elif Path(data_dir, "images.bin").exists():
            file_format = ".bin"
        else:
            raise ValueError(
                f"Unknown file format, as neither `{data_dir}/images.txt` or `{data_dir}/images.bin` could be found."
            )
        cameras, images, points3d = colmap_io.read_model(path=data_dir, ext=file_format)
        tracks = io_utils.tracks_from_colmap(images, points3d)
        image_data = io_utils.image_data_from_colmap(cameras, images)
        gtsam_cameras = {}
        for i, (_, wTi, calibration, _) in enumerate(image_data):
            camera_type = gtsfm_types.get_camera_class_for_calibration(calibration)
            gtsam_cameras[i] = camera_type(wTi, calibration)  # type: ignore

        gtsfm_data = cls(len(images), gtsam_cameras, tracks)
        for i, (image_name, _, _, image_shape) in enumerate(image_data):
            gtsfm_data.set_image_info(i, name=image_name, shape=image_shape)
        return gtsfm_data

    @classmethod
    def read_bal(cls, file_path: str) -> "GtsfmData":
        """Read a Bundle Adjustment in the Large" (BAL) file.

        See https://grail.cs.washington.edu/projects/bal/ for more details on the format.

        Args:
            file_path: File path of the BAL file.

        Returns:
            The data as a GtsfmData object.
        """
        sfm_data = gtsam.readBal(file_path)
        return cls.from_sfm_data(sfm_data)

    @classmethod
    def read_bundler(cls, file_path: str) -> "GtsfmData":
        """Read a Bundler file.

        Args:
            file_path: File path of the Bundler file.

        Returns:
            The data as a GtsfmData object.
        """
        sfm_data = gtsam.SfmData.FromBundlerFile(file_path)
        return cls.from_sfm_data(sfm_data)

    @classmethod
    def from_values(
        cls,
        values: Values,
        initial_data: Optional["GtsfmData"] = None,
        shared_calib: bool = False,
        include_cameras_not_in_values: bool = True,
        include_tracks_not_in_values: bool = False,
    ) -> "GtsfmData":
        """Instantiate a GtsfmData from optimized factor graph results.

        Args:
            values: Optimizer output containing poses, points, and calibrations.
            initial_data: Optional input data used to build the factor graph; provides topology for cameras and tracks.
            shared_calib: Whether all cameras shared a single calibration variable in the optimization.
            include_cameras_not_in_values: Whether to include cameras that are not in values (but are in initial_data).
        """

        def _symbol_indices(value_keys: Iterable[int], char: str) -> List[int]:
            indices = []
            for key in value_keys:
                symbol = gtsam.Symbol(key)
                if chr(symbol.chr()) == char:
                    indices.append(symbol.index())
            return sorted(indices)

        keys_list = list(values.keys())
        pose_indices = (
            initial_data.get_valid_camera_indices()
            if initial_data is not None and include_cameras_not_in_values
            else _symbol_indices(keys_list, "x")
        )

        if not pose_indices:
            return cls(0)

        number_images = initial_data.number_images() if initial_data is not None else (max(pose_indices) + 1)

        result = cls(number_images)

        calibration_extractors = (
            (gtsam.Cal3Fisheye, values.atCal3Fisheye),
            (gtsam.Cal3Bundler, values.atCal3Bundler),
            (gtsam.Cal3DS2, values.atCal3DS2),
            (gtsam.Cal3_S2, values.atCal3_S2),
        )

        calibration_type = None
        calibration_extractor = None

        if initial_data is not None:
            first_camera_idx = pose_indices[0]
            first_camera = initial_data.get_camera(first_camera_idx)
            assert first_camera is not None, "Initial data missing camera for reconstruction."
            calibration_type = type(first_camera.calibration())

        else:
            calib_indices = _symbol_indices(keys_list, "k")
            if calib_indices:
                calib_key = K(calib_indices[0])
                for candidate_type, extractor in calibration_extractors:
                    try:
                        extractor(calib_key)
                        calibration_type = candidate_type
                        calibration_extractor = extractor
                        break
                    except RuntimeError:
                        continue
            if calibration_type is None and calib_indices:
                raise ValueError("Unsupported calibration type encountered in Values.")

        if calibration_extractor is None and calibration_type is not None:
            for candidate_type, extractor in calibration_extractors:
                if candidate_type == calibration_type:
                    calibration_extractor = extractor
                    break

        if calibration_type is None:
            raise ValueError("Unable to determine calibration type for reconstruction.")

        def _calibration_for_idx(i: int) -> gtsfm_types.CALIBRATION_TYPE:
            key = K(0 if shared_calib else i)
            if calibration_extractor is not None:
                return calibration_extractor(key)
            assert initial_data is not None
            camera = initial_data.get_camera(i)
            assert camera is not None
            return camera.calibration()

        sample_calibration = _calibration_for_idx(pose_indices[0])
        camera_class = gtsfm_types.get_camera_class_for_calibration(sample_calibration)

        for i in pose_indices:
            cal_i = _calibration_for_idx(i)
            if values.exists(X(i)):
                result.add_camera(i, camera_class(values.atPose3(X(i)), cal_i))  # type: ignore
            elif initial_data and include_cameras_not_in_values:
                result.add_camera(i, initial_data.get_camera(i))

        track_indices = (
            _symbol_indices(keys_list, "p") if initial_data is None else list(range(initial_data.number_tracks()))
        )

        for track_idx in track_indices:
            if values.exists(P(track_idx)):
                point = values.atPoint3(P(track_idx))
                result_track = SfmTrack(point)
                if initial_data is not None:
                    input_track = initial_data.get_track(track_idx)
                    result_track.r = input_track.r
                    result_track.g = input_track.g
                    result_track.b = input_track.b
                    for measurement_idx in range(input_track.numberMeasurements()):
                        i, uv = input_track.measurement(measurement_idx)
                        if i in result.get_valid_camera_indices():
                            result_track.addMeasurement(i, uv)
                result.add_track(result_track)
            elif initial_data is not None and include_tracks_not_in_values:
                result_track = initial_data.get_track(track_idx)
                result.add_track(result_track)

        if initial_data is not None:
            result._image_info = initial_data._clone_image_info()
        if initial_data is not None and initial_data._camera_to_measurement_map is not None:
            result._camera_to_measurement_map = {
                k: v for k, v in initial_data._camera_to_measurement_map.items() if k in pose_indices
            }
        return result

    def __eq__(self, other: object) -> bool:
        """Checks equality with the other object."""

        if not isinstance(other, GtsfmData):
            return False

        if self._number_images != other.number_images():
            return False

        if self.has_gaussian_splats() != other.has_gaussian_splats():
            return False

        for i, cam in self._cameras.items():
            other_cam = other.get_camera(i)
            assert other_cam is not None
            if not cam.equals(other_cam, EQUALITY_TOLERANCE):  # type: ignore
                return False

        for j in range(self.number_tracks()):
            track = self.get_track(j)
            other_track = other.get_track(j)

            if track.numberMeasurements() != other_track.numberMeasurements():
                return False

            for k in range(track.numberMeasurements()):
                i, uv = track.measurement(k)
                other_i, other_uv = other_track.measurement(k)

                if i != other_i:
                    return False
                if not np.allclose(uv, other_uv):
                    return False

        return True

    def number_images(self) -> int:
        """Returns the number of images."""
        return self._number_images

    def tracks(self) -> List[SfmTrack]:
        """Returns all tracks."""
        return self._tracks

    def number_tracks(self) -> int:
        """Returns the number of tracks."""
        return len(self._tracks)

    def set_image_info(
        self,
        index: int,
        *,
        name: Optional[str] = None,
        shape: Optional[tuple[int, ...]] = None,
    ) -> None:
        """Attach optional metadata for image ``index``."""
        info = self._image_info.get(index, ImageInfo())
        if name is not None:
            info.name = str(name)
        if shape is not None:
            info.shape = tuple(int(x) for x in shape)
        self._image_info[index] = info

    def clone_with_image_data(self, images_by_index: Mapping[int, Image]) -> "GtsfmData":
        """Return a copy with image metadata populated and track RGB colors."""
        cloned = GtsfmData(self.number_images())
        cloned._image_info = self._clone_image_info()

        # Copy all cameras
        for idx, camera in self.cameras().items():
            cloned.add_camera(idx, camera)

        # Set image metadata from provided images
        for idx, img in images_by_index.items():
            if idx < 0 or idx >= cloned.number_images():
                continue
            info = cloned.get_image_info(idx)
            if info.name is None and img.file_name is not None:
                cloned.set_image_info(idx, name=img.file_name)
            if info.shape is None:
                cloned.set_image_info(idx, shape=img.shape)

        # Color and add all tracks
        for j in range(self.number_tracks()):
            src_track = self.get_track(j)
            colored_track = SfmTrack(src_track.point3())

            # Copy all measurements
            for k in range(src_track.numberMeasurements()):
                image_idx, uv = src_track.measurement(k)
                colored_track.addMeasurement(image_idx, uv)

            # Get color using the utility function (mean-based)
            r, g, b = image_utils.get_average_point_color(src_track, images_by_index)
            colored_track.r = r
            colored_track.g = g
            colored_track.b = b

            cloned.add_track(colored_track)

        if self._gaussian_splats is not None:
            cloned.set_gaussian_splats(self._gaussian_splats)
        cloned._pose_covariances = self._clone_pose_covariances(indices=cloned.get_valid_camera_indices())

        return cloned

    def get_image_info(self, index: int) -> ImageInfo:
        """Return metadata describing image ``index`` (lazily created)."""
        if index not in self._image_info:
            self._image_info[index] = ImageInfo()
        return self._image_info[index]

    def image_filenames(self) -> List[Optional[str]]:
        """Return list of image filenames, ordered by index."""
        return [self.get_image_info(i).name for i in self.get_valid_camera_indices()]

    def image_shapes(self) -> List[Optional[tuple[int, ...]]]:
        """Return list of image shapes, ordered by index."""
        return [self.get_image_info(i).shape for i in self.get_valid_camera_indices()]

    def _clone_image_info(self, indices: Optional[Iterable[int]] = None) -> dict[int, ImageInfo]:
        """Create a shallow copy of stored image metadata."""
        cloned: dict[int, ImageInfo] = {}
        source_indices = indices if indices is not None else self._image_info.keys()
        for idx in list(source_indices):
            if idx in self._image_info:
                info = self._image_info[idx]
                cloned[idx] = ImageInfo(name=info.name, shape=info.shape)
        return cloned

    def _clone_pose_covariances(self, indices: Optional[Iterable[int]] = None) -> dict[int, NDArray[np.float64]]:
        """Create a shallow copy of per-camera pose covariance blocks."""
        source_indices = indices if indices is not None else self._pose_covariances.keys()
        return {
            idx: np.array(self._pose_covariances[idx], copy=True)
            for idx in list(source_indices)
            if idx in self._pose_covariances
        }

    def _default_image_filename(self, index: int) -> str:
        """Return a placeholder filename for ``index``."""
        return f"image_{index:06d}.jpg"

    def _fallback_image_shape(self, index: int) -> tuple[int, int]:
        """Derive a plausible image shape from calibration when metadata is absent."""
        camera = self.get_camera(index)
        if camera is not None:
            calibration = camera.calibration()
            cx = getattr(calibration, "px", None)
            cy = getattr(calibration, "py", None)
            if callable(cx):
                cx = cx()
            if callable(cy):
                cy = cy()
            if isinstance(cx, (int, float)) and isinstance(cy, (int, float)):
                width = max(int(round(cx * 2)), 1)
                height = max(int(round(cy * 2)), 1)
                return (height, width)
        return (1, 1)

    def _normalize_shape(self, index: int, shape: Optional[tuple[int, ...]]) -> tuple[int, int]:
        """Ensure shapes are stored as (H, W) even if channels are present or missing."""
        if shape is None:
            return self._fallback_image_shape(index)
        if len(shape) == 0:
            return self._fallback_image_shape(index)
        height = int(shape[0])
        width = int(shape[1]) if len(shape) > 1 else height
        if height <= 0 or width <= 0:
            return self._fallback_image_shape(index)
        return (height, width)

    def _resolve_image_filename(self, index: int, name: Optional[str]) -> str:
        """Return a concrete filename, inventing a placeholder if missing."""
        if name is None or name == "":
            info = self._image_info.get(index)
            if info is not None and info.name:
                return info.name
            return self._default_image_filename(index)
        return name

    def get_valid_camera_indices(self) -> List[int]:
        """Returns indices of valid cameras."""
        return list(self._cameras.keys())

    def cameras(self) -> Dict[int, gtsfm_types.CAMERA_TYPE]:
        """Returns a dictionary of all cameras indexed by their image indices."""
        return self._cameras

    def get_camera(self, index: int) -> Optional[gtsfm_types.CAMERA_TYPE]:
        """Returns camera for given index, or None."""
        return self._cameras.get(index)

    def to_values(self, shared_calib: bool = False) -> Values:
        """Create a gtsam.Values populated with poses, calibrations, and landmarks."""
        values = Values()

        for loop_idx, i in enumerate(self.get_valid_camera_indices()):
            camera = self.get_camera(i)
            assert camera is not None, f"Camera {i} in GtsfmData is None"
            values.insert(X(i), camera.pose())
            if shared_calib and loop_idx == 0:
                values.insert(K(0), get_average_calibration(self))
            if not shared_calib:
                values.insert(K(i), camera.calibration())

        for track_idx in range(self.number_tracks()):
            track = self.get_track(track_idx)
            values.insert(P(track_idx), track.point3())

        return values

    def poses(self) -> Dict[int, Pose3]:
        """Returns poses as a dictionary, without missing poses."""
        return {i: cam.pose() for i, cam in self._cameras.items() if cam is not None}

    def get_camera_poses_list(self) -> List[Pose3 | None]:
        """Returns poses for all cameras (wTi), including missing ones as None.

        It is recommended to use get_camera_poses() instead, which returns a dictionary.
        # TODO: the number of images may be incorrect, which leaves this function buggy.

        Returns:
            List of poses for all cameras (wTi), including missing ones as None.
        """
        cameras = [self.get_camera(i) for i in range(self.number_images())]
        poses = [camera.pose() if camera is not None else None for camera in cameras]
        return poses

    def get_camera_poses(self) -> Dict[int, Pose3]:
        """Returns poses as a dictionary, without missing poses."""
        return {i: cam.pose() for i, cam in self._cameras.items()}

    def set_camera_pose_covariance(self, index: int, covariance: NDArray[np.float64]) -> None:
        """Set pose covariance for one camera index."""
        self._pose_covariances[index] = np.array(covariance, copy=True)

    def set_camera_pose_covariances(self, pose_covariances: Mapping[int, NDArray[np.float64]]) -> None:
        """Set pose covariances for multiple camera indices."""
        self._pose_covariances = {idx: np.array(cov, copy=True) for idx, cov in pose_covariances.items()}

    def get_camera_pose_covariance(self, index: int) -> Optional[NDArray[np.float64]]:
        """Get pose covariance for one camera index, if available."""
        covariance = self._pose_covariances.get(index)
        return None if covariance is None else np.array(covariance, copy=True)

    def get_camera_pose_covariances(self) -> Dict[int, NDArray[np.float64]]:
        """Get all available camera pose covariances."""
        return self._clone_pose_covariances()

    def get_track(self, index: int) -> SfmTrack:
        """Returns track at given index."""
        return self._tracks[index]

    def add_track(self, track: SfmTrack) -> bool:
        """Adds a track if all cameras exist; returns success flag."""
        for j in range(track.numberMeasurements()):
            i, _ = track.measurement(j)
            if i not in self._cameras:
                return False
        self._tracks.append(track)
        return True

    def get_tracks(self) -> List[SfmTrack]:
        """Returns all tracks."""
        return self._tracks

    def update_camera_pose(self, index: int, pose: Pose3) -> None:
        """Updates the pose of a camera at index."""
        if index not in self._cameras:
            raise ValueError(f"Camera at index {index} not found")
        K = self._cameras[index].calibration()
        new_camera = gtsfm_types.get_camera_class_for_calibration(K)(pose, K)
        self._cameras[index] = new_camera

    def update_camera(self, index: int, camera: gtsfm_types.CAMERA_TYPE) -> None:
        """Updates the camera at index."""
        if index not in self._cameras:
            raise ValueError(f"Camera at index {index} not found")
        self._cameras[index] = camera

    def add_camera(self, index: int, camera: gtsfm_types.CAMERA_TYPE) -> None:
        """Adds camera at index if not already present."""
        if camera is None:
            raise ValueError("Camera cannot be None, should be a valid camera")
        if index not in self._cameras:
            self._cameras[index] = camera
            self.get_image_info(index)  # ensure metadata entry exists

    def get_track_length_statistics(self) -> Tuple[float, float]:
        """Compute mean and median lengths of all the tracks.

        Returns:
            Mean track length.
            Median track length.
        """
        if self.number_tracks() == 0:
            return 0, 0

        track_lengths = self.get_track_lengths()
        return float(np.mean(track_lengths)), float(np.median(track_lengths))

    def get_track_lengths(self) -> np.ndarray:
        """Get an array containing the lengths of all tracks.

        Returns:
            Array containing all track lengths.
        """
        if self.number_tracks() == 0:
            return np.array([], dtype=np.uint32)

        track_lengths = [self.get_track(j).numberMeasurements() for j in range(self.number_tracks())]
        return np.array(track_lengths, dtype=np.uint32)

    def _populate_camera_to_measurement_map(self) -> None:
        """Populate the camera to measurement map."""
        if self._camera_to_measurement_map is None:
            self._camera_to_measurement_map = {}

        for track_idx in range(self.number_tracks()):
            track = self.get_track(track_idx)
            for m_idx in range(track.numberMeasurements()):
                i, _ = track.measurement(m_idx)
                if i not in self._camera_to_measurement_map:
                    self._camera_to_measurement_map[i] = [(track_idx, m_idx)]
                else:
                    self._camera_to_measurement_map[i].append((track_idx, m_idx))

    def get_camera_to_measurement_map(self) -> dict[int, list[tuple[int, int]]]:
        """Get the camera to measurement map."""
        if self._camera_to_measurement_map is None:
            self._populate_camera_to_measurement_map()
        assert self._camera_to_measurement_map is not None
        return self._camera_to_measurement_map

    def get_measurements_for_camera(self, camera_index: int) -> list[tuple[int, int]]:
        """Get the measurements for a camera."""
        if self._camera_to_measurement_map is None:
            self._populate_camera_to_measurement_map()
        assert self._camera_to_measurement_map is not None
        return self._camera_to_measurement_map.get(camera_index, [])

    def get_all_image_ids(self) -> list[int]:
        """Get all image ids: this is a superset of the valid camera indices, obtained from image_info."""
        if not self._image_info:
            return self.get_valid_camera_indices()
        return list(self._image_info.keys())

    def select_largest_connected_component(self, extra_camera_edges: Optional[ImageIndexPairs] = None) -> "GtsfmData":
        """Selects the subset of data belonging to the largest connected component of the graph where the edges are
        between cameras which feature in the same track.

        Args:
            extra_camera_edges (optional): edges which are to be considered as part of the graph when computing
                                           connected components.
        Returns:
            New GtSfmData object with the subset of tracks and cameras.
        """
        camera_edges = []
        for sfm_track in self._tracks:
            cameras_in_use = []
            for m_idx in range(sfm_track.numberMeasurements()):
                i, _ = sfm_track.measurement(m_idx)
                cameras_in_use.append(i)

            # Recreate track connectivity from track information
            # For example: a track has cameras [0, 2, 5]. In that case we will add pairs (0, 2), (0, 5), (2, 5)
            camera_edges += list(itertools.combinations(cameras_in_use, 2))

        # TODO(Ayush): add unit tests for extra camera edges
        if extra_camera_edges is not None:
            camera_edges += extra_camera_edges

        if len(camera_edges) == 0:
            data = GtsfmData(self._number_images, gaussian_splats=self._gaussian_splats)
            data._image_info = self._clone_image_info()
            data._pose_covariances = self._clone_pose_covariances()
            return data

        cameras_in_largest_cc = graph_utils.get_nodes_in_largest_connected_component(camera_edges)
        logger.info(
            "Largest connected component contains {} of {} cameras returned by front-end (of {} total imgs)".format(
                len(cameras_in_largest_cc), len(self.get_valid_camera_indices()), self._number_images
            )
        )
        return GtsfmData.from_selected_cameras(self, cameras_in_largest_cc, keep_all_image_infos=True)

    @classmethod
    def from_cameras_and_tracks(
        cls,
        cameras: Mapping[int, gtsfm_types.CAMERA_TYPE],
        tracks: List[SfmTrack],
        number_images: int,
        image_info: Optional[Mapping[int, ImageInfo]] = None,
        gaussian_splats: Optional[GaussianSplatsType] = None,
        pose_covariances: Optional[Mapping[int, NDArray[np.float64]]] = None,
    ) -> "GtsfmData":
        """Creates a GtsfmData object from a pre-existing set of cameras and tracks."""
        new_data = cls(number_images=number_images, gaussian_splats=gaussian_splats)
        new_data._cameras = dict(cameras)
        new_data._tracks = tracks
        if image_info is not None:
            new_data._image_info = {
                idx: ImageInfo(name=info.name, shape=info.shape) for idx, info in image_info.items()
            }
        if pose_covariances is not None:
            new_data.set_camera_pose_covariances(pose_covariances)
        return new_data

    @classmethod
    def from_selected_cameras(
        cls, gtsfm_data: "GtsfmData", camera_indices: List[int], keep_all_image_infos: bool = False
    ) -> "GtsfmData":
        """Selects the cameras in the input list and the tracks associated with those cameras.

        Args:
            gtsfm_data: data to pick the cameras from.
            camera_indices: camera indices to select and keep in the new data.

        Returns:
            New object with the selected cameras and associated tracks.
        """
        new_data = cls(number_images=gtsfm_data.number_images() if keep_all_image_infos else len(camera_indices))

        for i in gtsfm_data.get_valid_camera_indices():
            if i in camera_indices:
                camera_i = gtsfm_data.get_camera(i)
                assert camera_i is not None
                new_data.add_camera(i, camera_i)
                source_info = gtsfm_data.get_image_info(i)
                new_data.set_image_info(i, name=source_info.name, shape=source_info.shape)

        for i in gtsfm_data.get_all_image_ids():
            if i in camera_indices or keep_all_image_infos:
                source_info = gtsfm_data.get_image_info(i)
                new_data.set_image_info(i, name=source_info.name, shape=source_info.shape)

        new_camera_indices = new_data.get_valid_camera_indices()

        # add tracks which have all the camera present in new data
        for j in range(gtsfm_data.number_tracks()):
            track = gtsfm_data.get_track(j)
            is_valid = True
            for k in range(track.numberMeasurements()):
                i, _ = track.measurement(k)
                if i not in new_camera_indices:
                    is_valid = False
                    break
            if is_valid:
                new_data.add_track(track)

        if gtsfm_data._gaussian_splats is not None:
            new_data.set_gaussian_splats(gtsfm_data._gaussian_splats)

        if gtsfm_data._camera_to_measurement_map is not None:
            new_data._camera_to_measurement_map = {
                k: v for k, v in gtsfm_data._camera_to_measurement_map.items() if k in new_camera_indices
            }
        new_data._pose_covariances = gtsfm_data._clone_pose_covariances(indices=new_camera_indices)

        return new_data

    def get_scene_reprojection_errors(self) -> np.ndarray:
        """Get the scene reprojection errors for all 3D points and all associated measurements.

        Returns:
            Reprojection errors (measured in pixels) as a 1D numpy array.
        """
        scene_reproj_errors: List[float] = []
        for track in self._tracks:
            track_errors, _ = reprojection.compute_track_reprojection_errors(self._cameras, track)
            # passing an array argument to .extend() will convert the array to a list, and append its elements
            scene_reproj_errors.extend(track_errors)

        return np.array(scene_reproj_errors)

    def get_scene_reprojection_errors_per_camera(self) -> dict[int, np.ndarray]:
        """Get the reprojection errors for each camera."""
        reproj_errors_per_camera: dict[int, list[float]] = defaultdict(list)
        for track in self._tracks:
            track_errors, _ = reprojection.compute_track_reprojection_errors(self._cameras, track)
            for i, (cam_id, _) in enumerate(track.measurements):
                reproj_errors_per_camera[cam_id].append(track_errors[i])

        return {cam_id: np.array(errors) for cam_id, errors in reproj_errors_per_camera.items()}

    def aggregate_metrics(self) -> Mapping[str, Any]:
        """Aggregate metrics about the reprojection errors and 3d track lengths (summary stats).

        Args:
            ba_data: bundle adjustment result

        Returns:
            dictionary containing metrics of bundle adjustment result
        """
        track_lengths_3d = self.get_track_lengths()
        scene_reproj_errors = self.get_scene_reprojection_errors()

        def convert_to_rounded_float(x):
            return int(np.round(x, 3))

        stats_dict: dict[str, int | dict[str, int]] = {}
        stats_dict["number_tracks"] = self.number_tracks()
        stats_dict["3d_track_lengths"] = {
            "min": convert_to_rounded_float(track_lengths_3d.min()),
            "mean": convert_to_rounded_float(np.mean(track_lengths_3d)),
            "median": convert_to_rounded_float(np.median(track_lengths_3d)),
            "max": convert_to_rounded_float(track_lengths_3d.max()),
        }
        stats_dict["reprojection_errors_px"] = {
            "min": convert_to_rounded_float(np.nanmin(scene_reproj_errors)),
            "mean": convert_to_rounded_float(np.nanmean(scene_reproj_errors)),
            "median": convert_to_rounded_float(np.nanmedian(scene_reproj_errors)),
            "max": convert_to_rounded_float(np.nanmax(scene_reproj_errors)),
        }
        return stats_dict

    def get_avg_scene_reprojection_error(self) -> float:
        """Get average reprojection error for all 3d points in the entire scene

        Returns:
            Average of reprojection errors for every 3d point to its 2d measurements
        """
        scene_reproj_errors = self.get_scene_reprojection_errors()
        scene_avg_reproj_error = np.nan if np.isnan(scene_reproj_errors).all() else np.nanmean(scene_reproj_errors)
        return float(scene_avg_reproj_error)

    def log_scene_reprojection_error_stats(self) -> None:
        """Logs reprojection error stats for all 3d points in the entire scene."""
        scene_reproj_errors = self.get_scene_reprojection_errors()
        logger.info(
            "# cameras: %d, # tracks: %d, # images: %d", len(self.cameras()), self.number_tracks(), self.number_images()
        )
        logger.info(
            "Min scene reproj error: %.3f", np.nanmin(scene_reproj_errors) if len(scene_reproj_errors) else np.nan
        )
        logger.info(
            "Avg scene reproj error: %.3f", np.nanmean(scene_reproj_errors) if len(scene_reproj_errors) else np.nan
        )
        logger.info(
            "Median scene reproj error: %.3f", np.nanmedian(scene_reproj_errors) if len(scene_reproj_errors) else np.nan
        )
        logger.info(
            "Max scene reproj error: %.3f", np.nanmax(scene_reproj_errors) if len(scene_reproj_errors) else np.nan
        )

    def __validate_track(self, track: SfmTrack, reproj_err_thresh: float) -> bool:
        """Validates a track based on reprojection errors and cheirality checks.

        Args:
            track: track with 3D landmark and measurements.
            reproj_err_thresh: reprojection err threshold for each measurement.

        Returns:
            validity of the track.
        """
        errors, avg_reproj_error = reprojection.compute_track_reprojection_errors(self._cameras, track)
        # track is valid as all measurements have error below the threshold
        cheirality_success = np.all(~np.isnan(errors))
        return bool(np.all(errors < reproj_err_thresh) and cheirality_success)

    def filter_landmarks(self, reproj_err_thresh: float = 5) -> Tuple["GtsfmData", List[bool]]:
        """Filters out landmarks with high reprojection error

        Args:
            reproj_err_thresh: reprojection err threshold for each measurement.

        Returns:
            New instance, and list of valid flags, one for each track.
        """
        # TODO: move this function to utils or GTSAM
        filtered_data = GtsfmData(self.number_images(), gaussian_splats=self._gaussian_splats)
        filtered_data._image_info = self._clone_image_info()
        valid_mask = [self.__validate_track(track, reproj_err_thresh) for track in self._tracks]

        for track, valid in zip(self._tracks, valid_mask):
            if not valid:
                continue
            # check if all cameras with measurement in this track have already been added
            for k in range(track.numberMeasurements()):
                i, _ = track.measurement(k)
                camera_i = self.get_camera(i)
                assert camera_i is not None
                filtered_data.add_camera(i, camera_i)
                source_info = self.get_image_info(i)
                filtered_data.set_image_info(i, name=source_info.name, shape=source_info.shape)
            filtered_data.add_track(track)

        filtered_data._pose_covariances = self._clone_pose_covariances(indices=filtered_data.get_valid_camera_indices())
        return filtered_data, valid_mask

    def filter_landmark_measurements(
        self, reproj_err_thresh: float = 5, min_track_length: int = 2, retain_cameras_without_tracks: bool = True
    ) -> "GtsfmData":
        """Filters out landmarks with high reprojection error

        Args:
            reproj_err_thresh: reprojection err threshold for each measurement.

        Returns:
            New instance with filtered measurements/tracks.
        """
        # TODO: move this function to utils or GTSAM
        filtered_data = GtsfmData(self.number_images(), gaussian_splats=self._gaussian_splats)
        filtered_data._image_info = self._clone_image_info()

        for track in self._tracks:
            errors, _ = reprojection.compute_track_reprojection_errors(self._cameras, track)
            new_track = SfmTrack(track.point3())
            new_track.r = track.r
            new_track.g = track.g
            new_track.b = track.b
            track_cameras = set()
            for k in range(track.numberMeasurements()):
                if np.isnan(errors[k]) or errors[k] > reproj_err_thresh:
                    continue
                i, uv = track.measurement(k)
                new_track.addMeasurement(i, uv)
                track_cameras.add(i)
            if len(track_cameras) < min_track_length:
                continue
            for i in track_cameras:
                camera_i = self.get_camera(i)
                assert camera_i is not None
                filtered_data.add_camera(i, camera_i)
            filtered_data.add_track(new_track)
        logger.info(
            "Filtered_data now has %d cameras after adding cameres from tracks",
            len(filtered_data.get_valid_camera_indices()),
        )
        if retain_cameras_without_tracks:
            # Reinsert any cameras that were dropped only because all their measurements were filtered out.
            missing_cameras = set(self.cameras().keys()) - set(filtered_data.cameras().keys())
            logger.info("Cameras without tracks: count=%d, ids=%s", len(missing_cameras), sorted(missing_cameras))
            for i in missing_cameras:
                camera_i = self.get_camera(i)
                if camera_i is None:
                    continue
                filtered_data.add_camera(i, camera_i)

        filtered_data._pose_covariances = self._clone_pose_covariances(indices=filtered_data.get_valid_camera_indices())
        return filtered_data

    def align_via_sim3_and_transform(self, aTi: dict[int, Pose3]) -> "GtsfmData":
        """Return a copy of the scene aligned to the supplied reference poses via Sim(3).

        Args:
            wTi_list_ref: Reference/target camera poses, ordered by camera index.

        Returns:
            New GtsfmData aligned to the reference pose graph.
        """
        aSb = self.align_to_poses_via_sim3(aTi)
        return self.transform_with_sim3(aSb)

    def get_metrics(self, suffix: str, store_full_data: bool = False) -> List[GtsfmMetric]:
        """Helper to get bundle adjustment metrics from a GtsfmData object with a suffix for metric names."""
        metrics = []
        metrics.append(GtsfmMetric(name=f"number_images{suffix}", data=self.number_images()))
        metrics.append(GtsfmMetric(name=f"number_cameras{suffix}", data=len(self.get_valid_camera_indices())))
        metrics.append(GtsfmMetric(name=f"number_tracks{suffix}", data=self.number_tracks()))
        metrics.append(
            GtsfmMetric(
                name=f"3d_track_lengths{suffix}",
                data=self.get_track_lengths(),
                plot_type=GtsfmMetric.PlotType.HISTOGRAM,
                store_full_data=store_full_data,
            )
        )
        metrics.append(
            GtsfmMetric(
                name=f"reprojection_errors{suffix}_px",
                data=self.get_scene_reprojection_errors(),
                store_full_data=store_full_data,
                plot_type=GtsfmMetric.PlotType.BOX,
            )
        )
        return metrics

    def align_to_poses_via_sim3(self, aTi: dict[int, Pose3]) -> Similarity3:
        """Estimate a Sim(3) transformation that aligns the scene to the supplied reference poses.

        Args:
            wTi_list_ref: Reference/target camera poses, ordered by camera index.

        Returns:
            The estimated Sim(3) transformation aSb.
        """
        bTi_dict = self.get_camera_poses()
        return align.sim3_from_Pose3_maps_robust(aTi, bTi_dict)

    def transform_with_sim3(self, aSb: Similarity3) -> "GtsfmData":
        """Assume current tracks and cameras are in frame "b", then transport them to frame "a".

        Returns:
            New GtsfmData object which has been transformed from frame b to frame a.
        """
        aligned_data = GtsfmData(number_images=self.number_images())
        aligned_data._image_info = self._clone_image_info()

        # Update the camera poses to their aligned poses, but use the previous calibration.
        for idx, bTi_camera in self.cameras().items():
            assert bTi_camera is not None
            bTi = bTi_camera.pose()
            aTi = aSb.transformFrom(bTi)
            calibration = bTi_camera.calibration()
            camera_type = gtsfm_types.get_camera_class_for_calibration(calibration)
            aligned_data.add_camera(idx, camera_type(aTi, calibration))  # type: ignore
        # Align estimated tracks to ground truth.
        for j in range(self.number_tracks()):
            track_b = self.get_track(index=j)
            track_a = transform.track_with_sim3(aSb, track_b)
            aligned_data.add_track(track_a)

        if self._gaussian_splats is not None:
            aligned_data.set_gaussian_splats(transform_gaussian_splats(self._gaussian_splats, aSb))

        return aligned_data

    def merged_with(self, other: "GtsfmData", aSb: Similarity3, scale_focal_length: bool = False) -> "GtsfmData":
        """Return a new scene containing self and ``other`` transformed to this scene's frame.

        Args:
            other: Scene to merge, currently expressed in frame ``b``.
            aSb: Transform taking geometry from frame ``b`` to frame ``a`` (this scene).

        Returns:
            New ``GtsfmData`` containing cameras and tracks from both inputs.
        """
        merged_cameras = dict(self.cameras())
        transformed_other_cameras = transform.camera_map_with_sim3(
            aSb, other.cameras(), scale_focal_length=scale_focal_length
        )
        for key, camera in transformed_other_cameras.items():
            if key not in merged_cameras and camera is not None:
                merged_cameras[key] = camera

        merged_tracks = list(self.tracks())
        merged_tracks.extend(transform.tracks_with_sim3(aSb, other.tracks()))

        merged_image_info = self._clone_image_info()
        for idx in other.get_all_image_ids():
            if idx in merged_image_info:
                continue
            source_info = other.get_image_info(idx)
            merged_image_info[idx] = ImageInfo(name=source_info.name, shape=source_info.shape)

        merged_data = GtsfmData(number_images=len(merged_image_info))
        merged_data._image_info = merged_image_info

        for key, camera in merged_cameras.items():
            merged_data.add_camera(key, camera)

        for track in merged_tracks:
            merged_data._tracks.append(track)

        merged_gaussians: Optional[GaussianSplatsType] = None
        if self._gaussian_splats is not None:
            merged_gaussians = self._gaussian_splats
        if other._gaussian_splats is not None:
            transformed_other_gaussians = transform_gaussian_splats(other._gaussian_splats, aSb)
            if merged_gaussians is None:
                merged_gaussians = transformed_other_gaussians
            else:
                merged_gaussians = merge_gaussian_splats(merged_gaussians, transformed_other_gaussians)
        merged_data.set_gaussian_splats(merged_gaussians)
        # Keep only covariances for unchanged cameras from `self`. Cameras transformed from `other`
        # would require uncertainty transport through Sim(3), which is not handled here.
        merged_data._pose_covariances = self._clone_pose_covariances(indices=merged_data.get_valid_camera_indices())

        return merged_data

    def downsample(self, fraction_points_to_keep: float, seed: int = 42) -> "GtsfmData":
        """Downsample the number of 3D points in the scene by randomly selecting a fraction of them."""
        # TODO(Frank): extend to downsample cameras as well
        rng = np.random.default_rng(seed)
        num_tracks = self.number_tracks()
        indices_to_keep = rng.choice(num_tracks, size=int(num_tracks * fraction_points_to_keep), replace=False)
        downsampled_tracks = [self._tracks[idx] for idx in indices_to_keep]
        downsampled = GtsfmData(
            self.number_images(),
            self.cameras(),
            downsampled_tracks,
            gaussian_splats=self._gaussian_splats,
        )
        downsampled._image_info = self._clone_image_info()
        downsampled._pose_covariances = self._clone_pose_covariances(indices=downsampled.get_valid_camera_indices())
        return downsampled

    # COLMAP export functions

    def write_cameras(self, save_dir: str | Path) -> None:
        """Writes the camera data file in the COLMAP format.

        Reference: https://colmap.github.io/format.html#cameras-txt

        Args:
            save_dir: Folder to put the cameras.txt file in.
        """
        dir_path = Path(save_dir)
        dir_path.mkdir(parents=True, exist_ok=True)

        # TODO: handle shared intrinsics
        file_path = dir_path / "cameras.txt"
        with open(file_path, "w") as f:
            f.write("# Camera list with one line of data per camera:\n")
            f.write("#   CAMERA_ID, MODEL, WIDTH, HEIGHT, PARAMS[]\n")
            # note that we save the number of estimated cameras, not the number of input images,
            # which would instead be self.number_images().
            f.write(f"# Number of cameras: {len(self.get_valid_camera_indices())}\n")

            for i in self.get_valid_camera_indices():
                camera_i = self.get_camera(i)
                assert camera_i is not None, "Camera %d is None" % i
                gtsfm_cal = camera_i.calibration()
                info = self.get_image_info(i)
                height, width = info.shape
                colmap_cam = gtsfm_calibration_to_colmap_camera(i, gtsfm_cal, height, width)
                to_write = [colmap_cam.id, colmap_cam.model, colmap_cam.width, colmap_cam.height, *colmap_cam.params]
                line = " ".join([str(elem) for elem in to_write])
                f.write(line + "\n")

        if self._pose_covariances:
            covariance_path = dir_path / "covariance.txt"
            valid_camera_indices = self.get_valid_camera_indices()
            with open(covariance_path, "w") as f:
                f.write("# Camera pose covariance list with one line of data per camera:\n")
                f.write("#   CAMERA_ID, COVARIANCE_6X6_ROW_MAJOR[]\n")
                f.write(
                    "# Number of covariances: "
                    f"{sum(1 for i in valid_camera_indices if i in self._pose_covariances)}\n"
                )

                for i in valid_camera_indices:
                    covariance = self._pose_covariances.get(i)
                    if covariance is None:
                        continue
                    covariance_6x6 = np.asarray(covariance)[:6, :6]
                    row_major_values = covariance_6x6.reshape(-1)
                    line = " ".join([str(i), *[str(val) for val in row_major_values]])
                    f.write(line + "\n")

    def write_images(self, save_dir: str | Path) -> None:
        """Writes the image data file in the COLMAP format.

        Reference: https://colmap.github.io/format.html#images-txt
        Note: the "Number of images" saved to the .txt file is not the number of images
        fed to the SfM algorithm, but rather the number of localized camera poses/images,
        which COLMAP refers to as the "reconstructed cameras".

        Args:
            save_dir: Folder to put the images.txt file in.
        """
        dir_path = Path(save_dir)
        dir_path.mkdir(parents=True, exist_ok=True)

        num_imgs = self.number_images()

        if self._camera_to_measurement_map is None:
            self._populate_camera_to_measurement_map()
        num_obs = [len(v) for v in self._camera_to_measurement_map.values()]
        mean_obs_per_img = sum(num_obs) / (num_imgs if num_imgs > 0 else 1)

        file_path = dir_path / "images.txt"
        with open(file_path, "w") as f:
            f.write("# Image list with two lines of data per image:\n")
            f.write("#   IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID, NAME\n")
            f.write("#   POINTS2D[] as (X, Y, POINT3D_ID)\n")
            f.write(f"# Number of images: {num_imgs}, mean observations per image: {mean_obs_per_img:.3f}\n")

            for i in self.get_valid_camera_indices():
                camera = self.get_camera(i)
                assert camera is not None, "Camera %d is None" % i
                # COLMAP exports camera extrinsics (cTw), not the poses (wTc), so must invert
                iTw = camera.pose().inverse()
                iRw_quaternion = iTw.rotation().toQuaternion()
                itw = iTw.translation()
                tx, ty, tz = itw
                qw, qx, qy, qz = iRw_quaternion.w(), iRw_quaternion.x(), iRw_quaternion.y(), iRw_quaternion.z()

                image_info = self.get_image_info(i)
                filename = image_info.name
                resolved_name = self._resolve_image_filename(i, filename)
                f.write(f"{i} {qw} {qx} {qy} {qz} {tx} {ty} {tz} {i} {resolved_name}\n")

                # write out points2d
                for j in range(self.number_tracks()):
                    track = self.get_track(j)
                    for k in range(track.numberMeasurements()):
                        # write each measurement
                        image_id, uv_measured = track.measurement(k)
                        if image_id == i:
                            f.write(f" {uv_measured[0]:.3f} {uv_measured[1]:.3f} {j}")
                f.write("\n")

    def write_points(self, save_dir: str | Path) -> None:
        """Writes the point cloud data file in the COLMAP format.

        Reference: https://colmap.github.io/format.html#points3d-txt

        Args:
            self: Scene data to write.
            save_dir: Folder to put the points3D.txt file in.
        """
        dir_path = Path(save_dir)
        dir_path.mkdir(parents=True, exist_ok=True)

        num_pts = self.number_tracks()
        avg_track_length, _ = self.get_track_length_statistics()

        # Assign per-image indices to every keypoint so POINT2D_IDX matches COLMAP expectations.
        measurement_point2d_indices: Dict[tuple[int, int], int] = {}
        per_image_counts: defaultdict[int, int] = defaultdict(int)
        for track_idx in range(num_pts):
            track = self.get_track(track_idx)
            for measurement_idx in range(track.numberMeasurements()):
                image_id, _ = track.measurement(measurement_idx)
                measurement_point2d_indices[(track_idx, measurement_idx)] = per_image_counts[image_id]
                per_image_counts[image_id] += 1

        file_path = dir_path / "points3D.txt"
        with open(file_path, "w") as f:
            f.write("# 3D point list with one line of data per point:\n")
            f.write("#   POINT3D_ID, X, Y, Z, R, G, B, ERROR, TRACK[] as (IMAGE_ID, POINT2D_IDX)\n")
            f.write(f"# Number of points: {num_pts}, mean track length: {np.round(avg_track_length, 2)}\n")

            for j in range(num_pts):
                track = self.get_track(j)

                r = int(max(0, min(255, getattr(track, "r", 0))))
                g = int(max(0, min(255, getattr(track, "g", 0))))
                b = int(max(0, min(255, getattr(track, "b", 0))))
                x, y, z = track.point3()

                if track.numberMeasurements() > 0:
                    _, avg_track_error = reprojection.compute_track_reprojection_errors(self._cameras, track)
                    f.write(f"{j} {x} {y} {z} {r} {g} {b} {np.round(avg_track_error, 2)} ")
                    for k in range(track.numberMeasurements()):
                        i, uv_measured = track.measurement(k)
                        point2d_idx = measurement_point2d_indices[(j, k)]
                        f.write(f"{i} {point2d_idx} ")
                    f.write("\n")
                else:
                    # For tracks with no measurements (e.g., from dense point clouds), error is 0.
                    avg_track_error = 0.0
                    f.write(f"{j} {x} {y} {z} {r} {g} {b} {np.round(avg_track_error, 2)} \n")

    def export_as_colmap_text(
        self,
        save_dir: str | Path,
    ) -> None:
        """Emulates the COLMAP option to `Export model as text`.

        Three text files will be saved to disk: "points3D.txt", "images.txt", and "cameras.txt".
        If pose covariances are available, "covariance.txt" is also saved.

        Args:
            save_dir: Folder where text files will be saved.
        """
        image_ids = list(self._image_info.keys())

        # Make sure the image info is normalized and concrete.
        for idx in image_ids:
            info = self.get_image_info(idx)
            normalized_shape = self._normalize_shape(idx, info.shape)
            concrete_name = self._resolve_image_filename(idx, info.name)
            self.set_image_info(idx, name=concrete_name, shape=normalized_shape)

        self.write_cameras(save_dir)
        self.write_images(save_dir)
        self.write_points(save_dir)
