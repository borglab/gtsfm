"""Common pytorch utilities."""

import os
from typing import Optional, Sequence, Union

import gtsam  # type: ignore
import numpy as np
import torch
from gtsam import Point3, Pose3, Rot3, SfmTrack

import gtsfm.common.types as gtsfm_types


def default_device(device: Optional[Union[str, torch.device]] = None) -> torch.device:
    """Resolve a concrete device for PyTorch inference."""
    if device is not None:
        return torch.device(device)

    selected = os.environ.get("GTSFM_SELECTED_DEVICE", "").lower()
    if selected == "cpu":
        return torch.device("cpu")
    if selected == "mps":
        if not hasattr(torch.backends, "mps") or not torch.backends.mps.is_available():
            raise RuntimeError("The selected Apple MPS device is not available to PyTorch")
        return torch.device("mps")
    if selected.startswith(("cuda", "rocm")):
        if not torch.cuda.is_available():
            raise RuntimeError("The selected CUDA/ROCm device is not available to PyTorch")
        # The workspace narrows CUDA_VISIBLE_DEVICES, so the selected physical
        # device is intentionally exposed to this process as logical device 0.
        return torch.device("cuda:0")

    # Prefer CUDA if available, then MPS (Mac GPU), then fall back to CPU
    if torch.cuda.is_available():
        return torch.device("cuda")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")
    else:
        return torch.device("cpu")


def pose_from_extrinsic(matrix: np.ndarray) -> Pose3:
    """Convert an extrinsic matrix (camera-from-world) to a Pose3 (world-from-camera)."""
    cRw: np.ndarray = matrix[:3, :3]
    t = matrix[:3, 3]
    return Pose3(Rot3(cRw), Point3(*t)).inverse()


def pose_from_extrinsic_wTc(matrix: np.ndarray) -> Pose3:
    """Convert an extrinsic matrix (camera-to-world) to a Pose3 (camera-to-world)."""
    wRc: np.ndarray = matrix[:3, :3]
    t = matrix[:3, 3]
    return Pose3(Rot3(wRc), Point3(*t))


def cal3_s2_from_intrinsic(matrix: np.ndarray, crop_coords) -> gtsam.Cal3_S2:
    """Map a 3x3 intrinsic matrix to a Cal3_S2."""
    fx = float(matrix[0, 0])
    fy = float(matrix[1, 1])
    cx = float(matrix[0, 2])
    cy = float(matrix[1, 2])
    cx = cx + float(crop_coords[0])
    cy = cy + float(crop_coords[1])
    return gtsam.Cal3_S2(fx, fy, 0.0, cx, cy)


def cal3_bundler_from_intrinsic(matrix: np.ndarray, crop_coords) -> gtsam.Cal3Bundler:
    """Map a 3x3 intrinsic matrix to a Cal3Bundler."""
    fx = float(matrix[0, 0])
    fy = float(matrix[1, 1])
    f = (fx + fy) / 2.0
    cx = float(matrix[0, 2])
    cy = float(matrix[1, 2])
    cx = cx + float(crop_coords[0])
    cy = cy + float(crop_coords[1])
    return gtsam.Cal3Bundler(f, 0.0, 0.0, cx, cy)


def cal3ds2_from_intrinsic(matrix: np.ndarray, crop_coords) -> gtsam.Cal3_S2:
    """Map a 3x3 intrinsic matrix to a Cal3DS2."""
    fx = float(matrix[0, 0])
    fy = float(matrix[1, 1])
    cx = float(matrix[0, 2])
    cy = float(matrix[1, 2])
    cx = cx + float(crop_coords[0])
    cy = cy + float(crop_coords[1])
    return gtsam.Cal3DS2(fx, fy, 0.0, cx, cy, 0.0, 0.0, 0.0, 0.0)


def camera_from_matrices(
    extrinsic: np.ndarray,
    intrinsic: np.ndarray,
    crop_coords: np.ndarray,
    wTc_flag: bool = False,
    use_cal3_bundler: bool = False,
    use_cal3ds2: bool = False,
) -> gtsfm_types.CAMERA_TYPE:
    """Instantiate a Pinhole camera from raw extrinsic/intrinsic matrices."""
    if use_cal3ds2:
        calibration = cal3ds2_from_intrinsic(intrinsic, crop_coords)
    elif use_cal3_bundler:
        calibration = cal3_bundler_from_intrinsic(intrinsic, crop_coords)
    else:
        calibration = cal3_s2_from_intrinsic(intrinsic, crop_coords)
    if wTc_flag is True:
        pose = pose_from_extrinsic_wTc(extrinsic)
    else:
        pose = pose_from_extrinsic(extrinsic)
    return gtsfm_types.create_camera(pose, calibration)


def colored_track_from_point(
    point_xyz: np.ndarray,
    rgb: Optional[Sequence[float]] = None,
) -> SfmTrack:
    """Construct an SfmTrack with optional RGB color attributes."""
    coords = np.asarray(point_xyz, dtype=np.float64)
    track = SfmTrack(Point3(*coords))
    if rgb is not None:
        color = np.asarray(rgb, dtype=np.float64)
        track.r = float(color[0])
        track.g = float(color[1])
        track.b = float(color[2])
    return track
