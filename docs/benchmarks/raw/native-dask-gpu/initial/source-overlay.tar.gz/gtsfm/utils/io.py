"""Functions to provide I/O APIs for all the modules.

Authors: Ayush Baid, John Lambert
"""

import glob
import os
import pickle
from bz2 import BZ2File
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import h5py  # type: ignore
import numpy as np  # type: ignore
import open3d  # type: ignore
import simplejson as json  # type: ignore
from gtsam import Cal3Bundler, Pose3, Rot3, SfmTrack  # type: ignore
from PIL import Image as PILImage
from PIL.ExifTags import GPSTAGS, TAGS

import gtsfm.utils.images as image_utils
import gtsfm.utils.logger as logger_utils
import gtsfm.visualization.open3d_vis_utils as open3d_vis_utils
import thirdparty.colmap.scripts.python.read_write_model as colmap_io
from gtsfm.common.image import Image
from gtsfm.common.sfm_track import SfmTrack2d
from gtsfm.common.types import CALIBRATION_TYPE
from gtsfm.utils.pycolmap_utils import colmap_camera_to_gtsam_calibration
from thirdparty.colmap.scripts.python.read_write_model import Camera as ColmapCamera
from thirdparty.colmap.scripts.python.read_write_model import Image as ColmapImage
from thirdparty.colmap.scripts.python.read_write_model import Point3D as ColmapPoint3D

logger = logger_utils.get_logger()


IMG_EXTENSIONS = ["png", "PNG", "jpg", "JPG"]


def load_image(img_path: Union[str, Path]) -> Image:
    """Load the image from disk.

    Notes: EXIF is read as a map from (tag_id, value) where tag_id is an integer.
    In order to extract human-readable names, we use the lookup table TAGS or GPSTAGS.
    Images will be converted to RGB if in a different format.

    Args:
        img_path: The path of image to load (str or Path).

    Returns:
        Loaded image in RGB format.
    """
    img_path = str(img_path)
    original_image = PILImage.open(img_path)

    exif_data = original_image._getexif()
    if exif_data is not None:
        parsed_data = {}
        for tag_id, value in exif_data.items():
            # extract the human readable tag name
            if tag_id in TAGS:
                tag_name = TAGS.get(tag_id)
            elif tag_id in GPSTAGS:
                tag_name = GPSTAGS.get(tag_id)
            else:
                tag_name = tag_id
            parsed_data[tag_name] = value

        exif_data = parsed_data

    img_fname = Path(img_path).name
    converted_image = original_image.convert("RGB") if original_image.mode != "RGB" else original_image
    return Image(value_array=np.asarray(converted_image), exif_data=exif_data, file_name=img_fname)


def save_image(image: Image, img_path: str) -> None:
    """Saves the image to disk

    Args:
        image (np.array): Image.
        img_path: The path on disk to save the image to.
    """
    im = PILImage.fromarray(image.value_array)
    im.save(img_path)


def load_h5(file_path: str) -> Dict[Any, Any]:
    """Loads a dictionary from a h5 file

    Args:
        file_path: path of the h5 file

    Returns:
        the dictionary from the h5 file
    """
    data = {}

    with h5py.File(file_path, "r") as f:
        for key in f.keys():
            data[key] = f[key][:]

    return data


def save_json_file(
    json_fpath: str,
    data: Union[Dict[Any, Any], List[Any]],
) -> None:
    """Save a Python dictionary or list to a JSON file.
    Args:
        json_fpath: Path to file to create.
        data: Python dictionary or list to be serialized.
    """
    os.makedirs(os.path.dirname(json_fpath), exist_ok=True)
    with open(json_fpath, "w") as f:
        # ignore_nan=False replaces any NaN with null so downstream JSON parsers can handle it.
        json.dump(data, f, indent=4, ignore_nan=True)


def read_json_file(fpath: Union[str, Path]) -> Any:
    """Load dictionary from JSON file.

    Args:
        fpath: Path to JSON file.

    Returns:
        Deserialized Python dictionary or list.
    """
    with open(fpath, "r") as f:
        return json.load(f)


def colmap_image_id_to_idx(images: Dict[int, ColmapImage]) -> Dict[int, int]:
    """Map COLMAP image IDs to their corresponding indices in the GTSFM data structures."""
    imgs = list(images.values())
    sorted_idxs = _get_sorted_idx([im.name for im in imgs])
    return {imgs[i].id: new_idx for new_idx, i in enumerate(sorted_idxs)}


def tracks_from_colmap(images: Dict[int, ColmapImage], points3D: Dict[int, ColmapPoint3D]) -> List[SfmTrack]:
    """Extract SfmTracks from COLMAP data structures."""
    image_id_to_idx = colmap_image_id_to_idx(images)
    sfm_tracks_gtsfm: list[SfmTrack] = []
    for point3D in points3D.values():
        sfm_track = SfmTrack(point3D.xyz)
        sfm_track.r = point3D.rgb[0]
        sfm_track.g = point3D.rgb[1]
        sfm_track.b = point3D.rgb[2]
        for image_id, point2d_idx in zip(point3D.image_ids, point3D.point2D_idxs):
            sfm_track.addMeasurement(image_id_to_idx[image_id], images[image_id].xys[point2d_idx])
        sfm_tracks_gtsfm.append(sfm_track)

    return sfm_tracks_gtsfm


def image_data_from_colmap(
    cameras: Dict[int, ColmapCamera], images: Dict[int, ColmapImage]
) -> List[Tuple[str, Pose3, CALIBRATION_TYPE, Tuple[int, int]]]:
    """Extract image data from COLMAP data structures.

    Args:
        cameras: Dictionary of COLMAP-formatted Camera objects.
        images: Dictionary of COLMAP-formatted Image objects.

    Returns:
        a list of tuples containing:
            img_fname: File name of the image in images_gtsfm.
            wTi_gtsfm: Camera pose when the image was taken.
            intrinsics_gtsfm: Camera calibration corresponding to the image in images_gtsfm.
            img_dim: Dimensions of the image (H, W).
    """
    # Note: Assumes input cameras use `PINHOLE` model
    if len(images) == 0 and len(cameras) == 0:
        raise RuntimeError("No Image or Camera data provided to loader.")

    image_id_to_idx = colmap_image_id_to_idx(images)
    n = len(image_id_to_idx)
    out: List[Tuple[str, Pose3, CALIBRATION_TYPE, Tuple[int, int]]] = [None] * n  # type: ignore

    # We ignore missing IDs (un-estimated cameras) and re-order without them.
    for img in images.values():
        if img.id not in image_id_to_idx:
            continue
        idx = image_id_to_idx[img.id]
        camera = cameras[img.camera_id]
        out[idx] = (
            img.name,
            Pose3(Rot3(img.qvec2rotmat()), img.tvec).inverse(),
            colmap_camera_to_gtsam_calibration(camera),
            (camera.height, camera.width),
        )

    return out


def colmap2gtsfm(
    cameras: Dict[int, ColmapCamera], images: Dict[int, ColmapImage], points3D: Dict[int, ColmapPoint3D]
) -> Tuple[List[str], List[Pose3], List[CALIBRATION_TYPE], np.ndarray, np.ndarray, List[Tuple[int, int]]]:
    """Converts COLMAP-formatted variables to GTSfM format. NOTE(Frank): silly synced lists version

    Args:
        cameras: Dictionary of COLMAP-formatted Cameras.
        images: Dictionary of COLMAP-formatted Images.
        points3D: Dictionary of COLMAP-formatted Point3Ds.

    Returns:
        img_fnames: File names of images in images_gtsfm.
        wTi_gtsfm: List of N camera poses when each image was taken.
        intrinsics_gtsfm: List of N camera calibrations corresponding to the N images in images_gtsfm.
        point_cloud: (N,3) array representing xyz coordinates of 3d points.
        rgb: Uint8 array of shape (N,3) representing per-point colors.
        img_dims: List of dimensions of each img (H, W).
    """
    image_data = image_data_from_colmap(cameras, images)
    img_fnames, wTi_gtsfm, intrinsics_gtsfm, img_dims = zip(*image_data)
    point_cloud = np.array([point3d.xyz for point3d in points3D.values()])
    rgb = np.array([point3d.rgb for point3d in points3D.values()])
    return list(img_fnames), list(wTi_gtsfm), list(intrinsics_gtsfm), point_cloud, rgb, list(img_dims)


def read_cameras_txt(fpath: Union[str, Path]) -> Tuple[Optional[List[Cal3Bundler]], Optional[List[Tuple[int, int]]]]:
    """Read camera calibrations from a COLMAP-formatted cameras.txt file.

    Reference: https://colmap.github.io/format.html#cameras-txt

    Args:
        fpaths: Path to cameras.txt file.

    Returns:
        Tuple of:
            List of calibration objects for each camera, and list of dimensions of each img (H, W).
        Or (None, None) if fpath does not exist.
    """
    if not Path(fpath).exists():
        logger.info("%s does not exist", fpath)
        return None, None

    with open(fpath, "r") as f:
        lines = f.readlines()

    # May not be one line per camera (could be only one line of text if shared calibration)
    num_cams = int(lines[2].replace("# Number of cameras: ", "").strip())

    calibrations = []
    img_dims = []
    for i, line in enumerate(lines[3:]):
        cam_params = line.split()
        # Note that u0 is px, and v0 is py
        model = cam_params[1]
        img_w = int(cam_params[2])
        img_h = int(cam_params[3])
        # Currently only handles SIMPLE RADIAL and RADIAL camera models
        assert model in ["SIMPLE_RADIAL", "RADIAL", "PINHOLE"]
        if model == "SIMPLE_RADIAL":
            fx, u0, v0, k1 = map(float, cam_params[4:8])
            # Convert COLMAP's SIMPLE_RADIAL to GTSAM's Cal3Bundler:
            # Add second radial distortion coefficient of value zero.
            k2 = 0.0
        elif model == "RADIAL":
            fx, u0, v0, k1, k2 = map(float, cam_params[4:9])
        elif model == "PINHOLE":
            fx, _, u0, v0 = map(float, cam_params[4:8])
            k1, k2 = 0.0, 0.0
        else:
            logger.warning("Camera %d model %s not supported. Skipping this camera." % (i, model))
            continue
        calibrations.append(Cal3Bundler(fx, k1, k2, u0, v0))
        img_dims.append((img_h, img_w))
    assert len(calibrations) == num_cams
    return calibrations, img_dims


def read_images_txt(fpath: Union[str, Path]) -> Tuple[List[Pose3], List[str]]:
    """Read camera poses and image file names from a COLMAP-format images.txt file.

    Reference: https://colmap.github.io/format.html#images-txt
        "The coordinates of the projection/camera center are given by -R^t * T, where
        R^t is the inverse/transpose of the 3x3 rotation matrix composed from the
        quaternion and T is the translation vector. The local camera coordinate system
        of an image is defined in a way that the X axis points to the right, the Y axis
        to the bottom, and the Z axis to the front as seen from the image."

    Args:
        fpath: Path to images.txt file.

    Returns:
        wTi_list: List of camera poses for each image.
        img_fnames: Filename for each image.

    Raises:
        ValueError: If file path invalid.
    """
    if not Path(fpath).exists():
        raise FileNotFoundError(f"{fpath} does not exist.")

    with open(fpath, "r") as f:
        lines = f.readlines()

    wTi_list = []
    img_fnames = []
    # Ignore first 4 lines of text -- they contain a description of the file format
    # and a record of the number of reconstructed images.
    for line in lines[4::2]:
        i, qw, qx, qy, qz, tx, ty, tz, i, img_fname = line.split()
        # Colmap provides extrinsics, so must invert
        iRw = Rot3(float(qw), float(qx), float(qy), float(qz))
        wTi = Pose3(iRw, np.array([tx, ty, tz], dtype=np.float64)).inverse()
        wTi_list.append(wTi)
        img_fnames.append(img_fname)

    # TODO(johnwlambert): Re-order tracks for COLMAP-formatted .bin files.
    wTi_list_sorted, img_fnames_sorted, _ = sort_poses_and_filenames(wTi_list, img_fnames)

    return wTi_list_sorted, img_fnames_sorted


def _get_sorted_idx(img_fnames: List[str]) -> List[int]:
    """Get sorted indices of a list of image file names."""
    return sorted(range(len(img_fnames)), key=lambda i: img_fnames[i])


def sort_poses_and_filenames(wTi_list: List[Pose3], img_fnames: List[str]) -> Tuple[List[Pose3], List[str], List[int]]:
    """Sort a list of camera poses according to provided image file names."""
    sorted_idxs = _get_sorted_idx(img_fnames)

    wTi_list_sorted = [wTi_list[i] for i in sorted_idxs]
    img_fnames_sorted = [img_fnames[i] for i in sorted_idxs]

    return wTi_list_sorted, img_fnames_sorted, sorted_idxs


def read_points_txt(fpath: Union[str, Path]) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """Read 3d points and their associated colors from a COLMAP points.txt file.

    Reference: https://colmap.github.io/format.html#points3d-txt

    Args:
        fpath: Absolute file path to points.txt file.

    Returns:
        point_cloud: Float array of shape (N,3) representing per-point x/y/z coordinates.
        rgb: Uint8 array of shape (N,3) representing per-point colors.
    """
    if not Path(fpath).exists():
        logger.info("%s does not exist", fpath)
        return None, None

    with open(fpath, "r") as f:
        data = f.readlines()

    rgb = []
    point_cloud = []
    # First 3 lines are information about the file format.
    # line at index 2 will be of the form
    # "# Number of points: 2122, mean track length: 2.8449575871819039"
    points_metadata = data[2]
    j = points_metadata.find(":")
    k = points_metadata.find(",")
    expected_num_pts = int(points_metadata[j + 1 : k])

    data = data[3:]
    for line in data:
        entries = line.split()
        x, y, z, r, g, b = entries[1:7]

        point = [float(x), float(y), float(z)]
        point_cloud += [point]
        rgb += [(int(r), int(g), int(b))]

    point_cloud = np.array(point_cloud)
    rgb = np.array(rgb).astype(np.uint8)

    assert point_cloud.shape[0] == expected_num_pts
    assert rgb.shape[0] == expected_num_pts
    return point_cloud, rgb


def read_scene_data_from_colmap_format(
    data_dir: str,
) -> Tuple[List[Pose3], List[str], List[Cal3Bundler], np.ndarray, np.ndarray, List[Tuple[int, int]]]:
    """Reads in full scene reconstruction model from scene data stored in the COLMAP file format.

    Reference: https://colmap.github.io/format.html

    Args:
        data_dir: This directory should contain 3 files: either `cameras.txt`, `images.txt`, and `points3D.txt`, or
            `cameras.bin`, `images.bin`, and `points3D.bin`.

    Returns:
        6-tuple of:
            wTi_list: List of camera poses for each image.
            img_fnames: List of image file names, for each image.
            calibrations: Calibration object for each camera.
            point_cloud: Float array of shape (N,3) representing per-point x/y/z coordinates.
            rgb: Uint8 array of shape (N,3) representing per-point colors.
            img_dims: List of dimensions of each img (H, W).
    """
    # Determine whether scene data is stored in a text (txt) or binary (bin) file format.
    if Path(data_dir, "images.txt").exists():
        file_format = ".txt"
    elif Path(data_dir, "images.bin").exists():
        file_format = ".bin"
    else:
        raise ValueError(
            f"Unknown file format, as neither `{data_dir}/images.txt` or `{data_dir}/images.bin` could be found."
        )
    cameras, images, points3d = colmap_io.read_model(path=data_dir, ext=file_format)
    img_fnames, wTi_list, calibrations, point_cloud, rgb, img_dims = colmap2gtsfm(cameras, images, points3d)

    if any(x is None for x in [wTi_list, img_fnames, calibrations, point_cloud, rgb]):
        raise RuntimeError("One or more of the requested model data products was not found.")
    return wTi_list, img_fnames, calibrations, point_cloud, rgb, img_dims


def save_track_visualizations(
    tracks_2d: List[SfmTrack2d],
    images: List[Image],
    save_dir: str,
    viz_patch_sz: int = 100,
) -> None:
    """For every track, save an image with vertically stacked patches, each corresponding to a track keypoint.

    The visualizations can serve as a useful debugging tool for finding erroneous matches within tracks.
    """
    os.makedirs(save_dir, exist_ok=True)

    # Save each 2d track.
    for i, track in enumerate(tracks_2d):
        patches = []
        for m in track.measurements:
            patches += [images[m.i].extract_patch(center_x=m.uv[0], center_y=m.uv[1], patch_size=viz_patch_sz)]

        stacked_image = image_utils.vstack_image_list(patches)
        save_fpath = os.path.join(save_dir, f"track_{i}.jpg")
        save_image(stacked_image, img_path=save_fpath)


def read_from_bz2_file(file_path: Path) -> Optional[Any]:
    """Reads data using pickle from a compressed file, if it exists."""
    if not file_path.exists():
        return None

    try:
        data = pickle.load(BZ2File(file_path, "rb"))
    except Exception:
        logger.exception("Cache file was corrupted, removing it...")
        os.remove(file_path)
        data = None

    return data


def write_to_bz2_file(data: Any, file_path: Path) -> None:
    """Writes data using pickle to a compressed file."""
    file_path.parent.mkdir(exist_ok=True, parents=True)
    pickle.dump(data, BZ2File(file_path, "wb"))
    if not file_path.exists():
        logger.debug("Cache file could not be written!")


def save_point_cloud_as_ply(save_fpath: str, points: np.ndarray, rgb: Optional[np.ndarray] = None) -> None:
    """Save a point cloud as a .ply file.

    Args:
        save_fpath: Absolute file path where PLY file should be saved.
        points: Float array of shape (N,3) representing a 3d point cloud.
        rgb: Uint8 array of shape (N,3) representing an RGB color per point.
    """
    if rgb is None:
        # If no colors are provided, then color all points uniformly as black.
        N = points.shape[0]
        rgb = np.zeros((N, 3), dtype=np.uint8)
    pointcloud = open3d_vis_utils.create_colored_point_cloud_open3d(point_cloud=points, rgb=rgb)

    os.makedirs(Path(save_fpath).parent, exist_ok=True)
    open3d.io.write_point_cloud(save_fpath, pointcloud, write_ascii=False, compressed=False, print_progress=False)


def read_point_cloud_from_ply(ply_fpath: str) -> Tuple[np.ndarray, np.ndarray]:
    """Read a point cloud from a .ply file.

    Args:
        ply_fpath: Absolute file path where PLY file is located on disk.

    Returns:
        points: Float array of shape (N,3) representing a 3d point cloud.
        rgb: Uint8 array of shape (N,3) representing an RGB color per point.
    """
    pointcloud = open3d.io.read_point_cloud(ply_fpath)
    return open3d_vis_utils.convert_colored_open3d_point_cloud_to_numpy(pointcloud)


def get_sorted_image_names_in_dir(dir_path: str) -> List[str]:
    """Finds all jpg and png images in directory and returns their names in sorted order.

    Args:
        dir_path: Path to directory containing images.

    Returns:
        image_paths: List of image names in sorted order.
    """
    image_paths = []
    for extension in IMG_EXTENSIONS:
        search_path = os.path.join(dir_path, f"*.{extension}")
        image_paths.extend(glob.glob(search_path))

    return sorted(image_paths)


def save_poses(_poses, path):
    """Serialize and save poses to disk."""
    serialized = [p.serialize() for p in _poses]
    with open(path, "wb") as f:
        pickle.dump(serialized, f)


def load_poses(path):
    """Load and deserialize poses from disk."""
    with open(path, "rb") as f:
        serialized = pickle.load(f)
    _poses = []
    for s in serialized:
        pose = Pose3()
        pose.deserialize(s)
        _poses.append(pose)
    return _poses
