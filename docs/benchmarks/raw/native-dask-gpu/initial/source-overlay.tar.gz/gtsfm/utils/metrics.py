"""Utilities to compute and save evaluation metrics.

Authors: Ayush Baid, Akshay Krishnan
"""

import datetime
import itertools
import os
import timeit
from pathlib import Path
from typing import List, Optional, Sequence, Set, Tuple, Union

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns  # type: ignore
from gtsam import EssentialMatrix, Pose3, Rot3, Unit3  # type: ignore
from trimesh import Trimesh

import gtsfm.utils.geometry_comparisons as comp_utils
import gtsfm.utils.logger as logger_utils
import gtsfm.utils.verification as verification_utils
from gtsfm.common.keypoints import Keypoints
from gtsfm.common.types import CALIBRATION_TYPE, CAMERA_TYPE
from gtsfm.evaluation.metrics import GtsfmMetric, GtsfmMetricsGroup

REPO_ROOT = Path(__file__).resolve().parent.parent.parent

# A StatsDict is a dict from string to optional floats or their lists.
StatsDict = dict[str, Union[Optional[float], List[Optional[float]]]]

METRICS_PATH = Path(__file__).resolve().parent.parent.parent / "result_metrics"

EPSILON = 1e-12

logger = logger_utils.get_logger()


def compute_correspondence_metrics(
    keypoints_i1: Keypoints,
    keypoints_i2: Keypoints,
    corr_idxs_i1i2: np.ndarray,
    dist_threshold: float,
    gt_camera_i1: Optional[CAMERA_TYPE] = None,
    gt_camera_i2: Optional[CAMERA_TYPE] = None,
    gt_scene_mesh: Optional[Trimesh] = None,
) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """Checks the correspondences for epipolar distances and counts ones which are below the threshold.

    Args:
        keypoints_i1: keypoints in image i1.
        keypoints_i2: Corr. keypoints in image i2.
        intrinsics_i1: Intrinsics for i1.
        intrinsics_i2: Intrinsics for i2.
        dist_threshold: Max acceptable distance for a correct correspondence.
        gt_wTi1: Ground truth pose of image i1.
        gt_wTi2: Ground truth pose of image i2.
        gt_scene_mesh: Ground truth triangular surface mesh of the scene in the world frame.

    Raises:
        ValueError: When the number of keypoints do not match.

    Returns:
        Boolean mask of which verified correspondences are classified as correct under Sampson error
            (using GT epipolar geometry).
        Reprojection error for every verified correspondence against GT geometry.
    """
    if corr_idxs_i1i2.size == 0:
        return None, None

    if gt_camera_i1 is None or gt_camera_i2 is None:
        return None, None

    # Compute ground truth correspondences.
    matched_keypoints_i1 = keypoints_i1.extract_indices(corr_idxs_i1i2[:, 0])
    matched_keypoints_i2 = keypoints_i2.extract_indices(corr_idxs_i1i2[:, 1])
    # Check to see if a GT mesh is provided.
    if gt_scene_mesh is not None:
        return mesh_inlier_correspondences(
            matched_keypoints_i1,
            matched_keypoints_i2,
            gt_camera_i1,
            gt_camera_i2,
            gt_scene_mesh,
            dist_threshold,
        )

    # If no mesh is provided, use squared Sampson error.
    gt_i2Ti1 = gt_camera_i2.pose().between(gt_camera_i1.pose())
    return epipolar_inlier_correspondences(
        matched_keypoints_i1,
        matched_keypoints_i2,
        gt_camera_i1.calibration(),
        gt_camera_i2.calibration(),
        gt_i2Ti1,
        dist_threshold,
    )


def epipolar_inlier_correspondences(
    keypoints_i1: Keypoints,
    keypoints_i2: Keypoints,
    intrinsics_i1: CALIBRATION_TYPE,
    intrinsics_i2: CALIBRATION_TYPE,
    i2Ti1: Pose3,
    dist_threshold: float,
) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """Compute inlier correspondences using epipolar geometry and the ground truth relative pose.

    Args:
        keypoints_i1: Keypoints in image i1.
        keypoints_i2: corr. keypoints in image i2.
        intrinsics_i1: Intrinsics for i1.
        intrinsics_i2: Intrinsics for i2.
        i2Ti1: Relative pose
        dist_threshold: Max acceptable distance for a correct correspondence.

    Returns:
        is_inlier: (N, ) mask of inlier correspondences.
        distance_squared: Squared sampson distance between corresponding keypoints.
    """
    i2Ei1 = EssentialMatrix(i2Ti1.rotation(), Unit3(i2Ti1.translation()))
    i2Fi1 = verification_utils.essential_to_fundamental_matrix(i2Ei1, intrinsics_i1, intrinsics_i2)
    distance_squared = verification_utils.compute_epipolar_distances_sq_sampson(
        keypoints_i1.coordinates, keypoints_i2.coordinates, i2Fi1
    )
    is_inlier = distance_squared < dist_threshold**2 if distance_squared is not None else None

    return is_inlier, distance_squared


def mesh_inlier_correspondences(
    keypoints_i1: Keypoints,
    keypoints_i2: Keypoints,
    gt_camera_i1: CAMERA_TYPE,
    gt_camera_i2: CAMERA_TYPE,
    gt_scene_mesh: Trimesh,
    dist_threshold: float,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute inlier correspondences using the ground truth triangular surface mesh of the scene. First, rays are
    back-projected at each keypoint in the images and intersections between these rays and the ground truth mesh are
    recorded. Next, given a match, the mesh intersections corresponding to each keypoint are forward-projected into the
    other image and the reprojection error is computed to decide whether the match is an inlier.

    Args:
        keypoints_i1: N keypoints in image i1.
        keypoints_i2: N corresponding keypoints in image i2.
        gt_camera_i1: Ground truth camera for image i1, i.e., wTi1 and intrinsics.
        gt_camera_i1: Ground truth camera for image i2, i.e., wTi2 and intrinsics.
        gt_scene_mesh: Ground truth triangular surface mesh of the scene in the world frame.
        dist_threshold: Max acceptable reprojection error (in pixels) between image coordinates of ground truth landmark
            and keypoint.

    Returns:
        is_inlier: (N, ) mask of inlier correspondences.
        reprojection_error: Maximum error between forward-projected ground truth landmark and corresponding keypoints

    Raises:
        ValueError: If the number of keypoints do not match.
    """
    if len(keypoints_i1) != len(keypoints_i2):
        raise ValueError("Keypoints must have same counts")
    n_correspondences = len(keypoints_i1)
    is_inlier = np.zeros(n_correspondences, dtype=bool)

    # Perform ray tracing to compute keypoint intersections.
    keypoint_ind_i1, intersections_i1 = compute_keypoint_intersections(keypoints_i1, gt_camera_i1, gt_scene_mesh)
    keypoint_ind_i2, intersections_i2 = compute_keypoint_intersections(keypoints_i2, gt_camera_i2, gt_scene_mesh)
    keypoint_ind, i1_idx, i2_idx = np.intersect1d(keypoint_ind_i1, keypoint_ind_i2, return_indices=True)

    # Forward project intersections into other image to compute error.
    reprojection_error = np.array([np.nan] * len(keypoints_i1))
    for i in range(len(keypoint_ind)):
        uv_i1 = keypoints_i1.coordinates[keypoint_ind[i]]
        uv_i2 = keypoints_i2.coordinates[keypoint_ind[i]]
        uv_i2i1, success_flag_i1 = gt_camera_i1.projectSafe(intersections_i2[i2_idx[i]])  # type: ignore
        uv_i1i2, success_flag_i2 = gt_camera_i2.projectSafe(intersections_i1[i1_idx[i]])  # type: ignore
        if success_flag_i1 and success_flag_i2:
            err_i2i1 = np.linalg.norm(uv_i1 - uv_i2i1)
            err_i1i2 = np.linalg.norm(uv_i2 - uv_i1i2)
            is_inlier[keypoint_ind[i]] = max(float(err_i2i1), float(err_i1i2)) < dist_threshold
            reprojection_error[keypoint_ind[i]] = max(float(err_i2i1), float(err_i1i2))
        else:
            is_inlier[keypoint_ind[i]] = False
            reprojection_error[keypoint_ind[i]] = np.nan

    return is_inlier, reprojection_error


def compute_keypoint_intersections(
    keypoints: Keypoints, gt_camera: CAMERA_TYPE, gt_scene_mesh: Trimesh, verbose: bool = False
) -> Tuple[np.ndarray, np.ndarray]:
    """Computes intersections between ground truth surface mesh and rays originating from image keypoints.

    Args:
        keypoints: N keypoints computed in image.
        gt_camera: Ground truth camera.
        gt_scene_mesh: Ground truth triangular surface mesh.

    Returns:
        keypoint_ind: (M,) array of keypoint indices whose corresponding ray intersected the ground truth mesh.
        intersections_locations: (M, 3), array of ray intersection locations.
    """
    num_keypoints = len(keypoints)
    src = np.repeat(gt_camera.pose().translation().reshape((-1, 3)), num_keypoints, axis=0)  # At_i1A
    drc = np.asarray(
        [gt_camera.backproject(keypoints.coordinates[i], depth=1.0) - src[i, :] for i in range(num_keypoints)]
    )
    start_time = timeit.default_timer()
    intersections, keypoint_ind, _ = gt_scene_mesh.ray.intersects_location(src, drc, multiple_hits=False)
    if verbose:
        logger.debug("🚀 Case %d rays in %.6f seconds.", num_keypoints, timeit.default_timer() - start_time)

    return keypoint_ind, intersections


def compute_rotation_angle_metric(
    wRi: dict[int | str, Optional[Rot3]],
    gt_wRi: dict[int | str, Optional[Rot3]],
    store_full_data: bool = False,
) -> GtsfmMetric:
    """Computes statistics for the angle between estimated and GT rotations.

    Assumes that the estimated and GT rotations have been aligned and do not
    have a gauge freedom.

    Args:
        wRi: Estimated camera rotations keyed by image id.
        gt_wRi: Ground truth camera rotations keyed by image id.

    Returns:
        A GtsfmMetric for the rotation angle errors, in degrees.
    """
    ordered_ids = sorted(gt_wRi.keys())
    errors = [comp_utils.compute_relative_rotation_angle(wRi.get(i), gt_wRi[i]) for i in ordered_ids]
    return GtsfmMetric("rotation_angle_error_deg", errors, store_full_data=store_full_data)


def compute_translation_distance_metric(
    wti: dict[int | str, Optional[np.ndarray]],
    gt_wti: dict[int | str, Optional[np.ndarray]],
    store_full_data: bool = False,
) -> GtsfmMetric:
    """Computes statistics for the distance between estimated and GT translations.

    Assumes that the estimated and GT translations have been aligned and do not
    have a gauge freedom (including scale).

    Args:
        wti: Estimated camera translations keyed by image id.
        gt_wti: Ground truth camera translations keyed by image id.

    Returns:
        A statistics dict of the metrics errors in degrees.
    """
    ordered_ids = sorted(gt_wti.keys())
    errors = [comp_utils.compute_points_distance_l2(wti.get(i), gt_wti[i]) for i in ordered_ids]
    return GtsfmMetric("translation_error_distance", errors, store_full_data=store_full_data)


def get_relative_translation_angles(
    i2Ui1: dict[Tuple[int, int] | Tuple[str, str], Optional[Unit3]],
    wTi: dict[int | str, Optional[Pose3]],
    include_none: bool = False,
) -> List[float]:
    """Returns a list of relative translation angles, with optional `np.nan` entries for missing poses.

    If either pose in a pair is ``None`` and ``include_none`` is:
      * ``False``: that pair is skipped and contributes no entry to the output list.
      * ``True``: a ``np.nan`` value is appended to the output list for that pair.

    Args:
        i2Ui1: Relative translation directions keyed by (i1, i2).
        wTi: Camera poses keyed by image id.
        include_none: Whether to include pose pairs with missing poses in the metrics by appending ``np.nan``
            for those pairs instead of skipping them.

    Returns:
        A list of relative translation angles, in degrees.
    """
    angles: List[float] = []
    valid_i2Ui1 = {k: val for k, val in i2Ui1.items() if val is not None}
    for (i1, i2), i2Ui1_val in valid_i2Ui1.items():
        poses_missing = wTi.get(i1) is None or wTi.get(i2) is None
        if poses_missing and include_none:
            angles.append(np.nan)
            continue
        elif poses_missing:
            continue
        angle = comp_utils.compute_translation_to_direction_angle(i2Ui1_val, wTi.get(i2), wTi.get(i1))
        assert angle is not None
        angles.append(angle)
    return angles


def compute_relative_translation_angle_metric(
    i2Ui1: dict[Tuple[int, int] | Tuple[str, str], Optional[Unit3]],
    wTi: dict[int | str, Optional[Pose3]],
    prefix: str = "",
    store_full_data: bool = False,
) -> GtsfmMetric:
    """Computes statistics for angle between translations and direction measurements.

    Args:
        i2Ui1: Translation direction measurements keyed by (i1, i2).
        wTi: Estimated camera poses keyed by image id.

    Returns:
        A GtsfmMetric for the relative translation angle errors, in degrees.
    """
    angles = get_relative_translation_angles(i2Ui1, wTi)
    return GtsfmMetric(
        prefix + "relative_translation_angle_error_deg",
        np.array(angles, dtype=np.float32),
        store_full_data=store_full_data,
    )


def get_relative_rotation_angles(
    i2Ri1: dict[Tuple[int, int], Optional[Rot3]],
    wTi: dict[int, Optional[Pose3]],
    include_none: bool = False,
) -> List[float]:
    """Returns a list of relative rotation angles, in degrees.

    This function iterates over all provided relative rotations and their corresponding
    poses, and computes the angle between each estimated relative rotation and the
    ground-truth relative rotation (derived from ``wTi``).

    - Pairs whose relative rotation ``i2Ri1`` is ``None`` are always skipped and never
      contribute a value to the returned list, regardless of ``include_none``.
    - For pairs where ``i2Ri1`` is valid but either ``wTi[i1]`` or ``wTi[i2]``
      is ``None``, the behavior depends on ``include_none``:

        * If ``include_none`` is ``False`` (default), such pairs are skipped.
        * If ``include_none`` is ``True``, a ``np.nan`` value is appended to the
          returned list for each such pair, so they are still represented in the
          metrics instead of being omitted.

    Args:
        i2Ri1: Relative rotations keyed by (i1, i2).
        wTi: Camera poses keyed by image id.
        include_none: Whether to include pairs with missing poses in the metrics by
            appending ``np.nan`` values (when ``True``) instead of skipping them.

    Returns:
        A list of relative rotation angles, in degrees, optionally containing
        ``np.nan`` entries for pairs with missing poses when ``include_none`` is True.
    """
    angles: List[float] = []
    valid_i2Ri1 = {k: val for k, val in i2Ri1.items() if val is not None}
    for (i1, i2), i2Ri1_val in valid_i2Ri1.items():
        poses_missing = wTi.get(i1) is None or wTi.get(i2) is None
        if poses_missing and include_none:
            angles.append(np.nan)
            continue
        elif poses_missing:
            continue
        wRi1_gt = wTi[i1].rotation()  # type: ignore
        wRi2_gt = wTi[i2].rotation()  # type: ignore
        i2Ri1_gt = wRi2_gt.between(wRi1_gt)
        angle = comp_utils.compute_relative_rotation_angle(i2Ri1_val, i2Ri1_gt)
        assert angle is not None
        angles.append(angle)
    return angles


def compute_relative_rotation_angle_metric(
    i2Ri1: dict[Tuple[int, int], Optional[Rot3]],
    wTi: dict[int, Optional[Pose3]],
    store_full_data: bool = False,
) -> GtsfmMetric:
    """Computes statistics for angle between relative rotations and ground truth."""
    angles = get_relative_rotation_angles(i2Ri1, wTi)
    return GtsfmMetric(
        "relative_rotation_angle_error_deg", np.array(angles, dtype=np.float32), store_full_data=store_full_data
    )


def compute_translation_angle_metric(
    gt_wTi: dict[int | str, Optional[Pose3]],
    wTi: dict[int | str, Optional[Pose3]],
    store_full_data: bool = False,
) -> GtsfmMetric:
    """Compute global translation angular errors from aligned pose graphs.

    Args:
        gt_wTi: Ground truth camera poses keyed by image id.
        wTi: Aligned, estimated camera poses keyed by image id.

    Returns:
        A GtsfmMetric for the N global translation angle errors, in degrees.
    """
    angles = []
    for i in sorted(gt_wTi.keys()):
        est_pose = wTi.get(i)
        gt_pose = gt_wTi[i]
        if est_pose is not None and gt_pose is not None:
            wUi_est = Unit3(est_pose.translation())
            wUi_gt = Unit3(gt_pose.translation())
            angle = comp_utils.compute_relative_unit_translation_angle(wUi_est, wUi_gt)
        else:
            angle = np.nan
        angles.append(angle)
    return GtsfmMetric(
        "translation_angle_error_deg", np.array(angles, dtype=np.float32), store_full_data=store_full_data
    )


def compute_pose_auc_metric(
    rotation_angular_errors: Union[Sequence[float], np.ndarray],
    translation_angular_errors: Union[Sequence[float], np.ndarray],
    thresholds_deg: Sequence[float] = (1.0, 2.5, 3.0, 5.0, 10.0, 20.0),
    save_dir: Optional[str] = None,
    metric_name_prefix: str = "pose_auc",
) -> List[GtsfmMetric]:
    """Computes "Pose AUC" metric from rotation & translation angular errors.

    Args:
        rotation_angular_errors: N rotation angular errors, in degrees.
        translation_angular_errors: N translation angular errors, in degrees.
        metric_name_prefix: Prefix for output metric names.

    Returns:
        One GtsfmMetric for each angular error threshold.
    """
    if len(rotation_angular_errors) != len(translation_angular_errors):
        raise ValueError("# of rotation and translation angular errors must match.")

    if not isinstance(rotation_angular_errors, np.ndarray):
        rotation_angular_errors = np.array(rotation_angular_errors)
    rotation_angular_errors = np.nan_to_num(rotation_angular_errors, nan=np.inf)

    if not isinstance(translation_angular_errors, np.ndarray):
        translation_angular_errors = np.array(translation_angular_errors)
    translation_angular_errors = np.nan_to_num(translation_angular_errors, nan=np.inf)

    pose_errors = np.maximum(rotation_angular_errors, translation_angular_errors)
    AUCs = pose_auc(pose_errors, thresholds_deg, save_dir=save_dir)
    metrics = []
    for threshold, auc in zip(thresholds_deg, AUCs):
        metrics.append(GtsfmMetric(f"{metric_name_prefix}_@{threshold}_deg", auc))
    return metrics


def compute_ba_pose_metrics(
    gt_wTi: dict[int, Pose3],
    computed_wTi: dict[int, Optional[Pose3]],
    save_dir: Optional[str] = None,
    store_full_data: bool = False,
    metric_constructed_only: bool = False,
) -> GtsfmMetricsGroup:
    """Compute pose errors w.r.t. GT for the bundle adjustment result.

    Note: inputs must be aligned beforehand to the ground truth.

    Args:
        gt_wTi: Dict of ground truth poses keyed by camera id.
        computed_wTi: Dict of computed poses keyed by camera id.
        save_dir: Directory to save the metrics plots.
        store_full_data: Whether to store full data.
        metric_constructed_only: Whether pose AUC should only consider reconstructed image pairs.

    Returns:
        A group of metrics that describe errors associated with a bundle adjustment result (w.r.t. GT).
    """
    i2Ri1_gt, i2Ui1_gt = get_all_relative_rotations_translations(gt_wTi)
    i2Ui1_gt_opt: dict[Tuple[int, int], Optional[Unit3]] = {k: v for k, v in i2Ui1_gt.items()}
    i2Ri1_gt_opt: dict[Tuple[int, int], Optional[Rot3]] = {k: v for k, v in i2Ri1_gt.items()}

    camera_idxs = sorted(list(gt_wTi.keys()))

    computed_wTi_list = [computed_wTi[i] if i in computed_wTi else None for i in camera_idxs]
    gt_wTi_list = [gt_wTi[i] for i in camera_idxs]
    wRi_aligned, wti_aligned = get_rotations_translations_from_poses(
        {i: pose for i, pose in zip(camera_idxs, computed_wTi_list)}
    )
    gt_wRi, gt_wti = get_rotations_translations_from_poses({i: pose for i, pose in zip(camera_idxs, gt_wTi_list)})

    metrics = []
    metrics.append(compute_rotation_angle_metric(wRi_aligned, gt_wRi))
    metrics.append(compute_translation_distance_metric(wti_aligned, gt_wti))
    computed_wTi_opt: dict[int, Optional[Pose3]] = {i: pose for i, pose in zip(camera_idxs, computed_wTi_list)}
    gt_wTi_opt: dict[int, Optional[Pose3]] = {i: pose for i, pose in gt_wTi.items()}
    translation_angular_errors = get_relative_translation_angles(i2Ui1_gt_opt, computed_wTi_opt, include_none=True)
    metrics.append(
        GtsfmMetric(
            "relative_translation_angle_error_deg",
            np.array(translation_angular_errors, dtype=np.float32),
            store_full_data=store_full_data,
        )
    )
    metrics.append(compute_translation_angle_metric(gt_wTi_opt, computed_wTi_opt))
    rotation_angular_errors = get_relative_rotation_angles(i2Ri1_gt_opt, computed_wTi_opt, include_none=True)
    metrics.append(
        GtsfmMetric(
            "relative_rotation_angle_error_deg",
            np.array(rotation_angular_errors, dtype=np.float32),
            store_full_data=store_full_data,
        )
    )

    metrics.extend(compute_pose_auc_metric(rotation_angular_errors, translation_angular_errors, save_dir=save_dir))
    if metric_constructed_only:
        # Compute pose AUC using only constructed image pairs (exclude missing poses).
        constructed_rotation_angular_errors = get_relative_rotation_angles(
            i2Ri1_gt_opt, computed_wTi_opt, include_none=False
        )
        constructed_translation_angular_errors = get_relative_translation_angles(
            i2Ui1_gt_opt, computed_wTi_opt, include_none=False
        )
        metrics.extend(
            compute_pose_auc_metric(
                constructed_rotation_angular_errors,
                constructed_translation_angular_errors,
                save_dir=save_dir,
                metric_name_prefix="pose_auc_constructed_only",
            )
        )

    return GtsfmMetricsGroup(name="ba_pose_error_metrics", metrics=metrics)


def compute_intrinsics_metrics(
    gt_cameras: dict[int, CAMERA_TYPE],
    computed_cameras: dict[int, CAMERA_TYPE],
    store_full_data: bool = False,
) -> GtsfmMetricsGroup:
    """Compute intrinsics error metrics per camera w.r.t. ground truth.

    Reports focal length percentage error and, when the calibration model supports it,
    raw absolute errors for radial distortion parameters (k1, k2).

    Args:
        gt_cameras: Ground truth cameras keyed by image index.
        computed_cameras: Estimated cameras keyed by image index.
        store_full_data: Whether to store the full array of per-camera errors.

    Returns:
        A GtsfmMetricsGroup with focal length and (optionally) distortion error distributions.
    """
    common_indices = sorted(set(gt_cameras.keys()) & set(computed_cameras.keys()))
    if len(common_indices) == 0:
        return GtsfmMetricsGroup(name="intrinsics_metrics", metrics=[])

    focal_pct_errors = []
    focal_abs_errors = []
    k1_errors = []
    k2_errors = []
    for i in common_indices:
        gt_cal = gt_cameras[i].calibration()
        est_cal = computed_cameras[i].calibration()
        gt_f = gt_cal.fx()
        focal_abs_errors.append(abs(est_cal.fx() - gt_f))
        if gt_f > 0:
            focal_pct_errors.append(abs(est_cal.fx() - gt_f) / gt_f * 100.0)
        if hasattr(gt_cal, "k1") and hasattr(est_cal, "k1"):
            k1_errors.append(abs(est_cal.k1() - gt_cal.k1()))
            k2_errors.append(abs(est_cal.k2() - gt_cal.k2()))

    metrics = [
        GtsfmMetric(
            "focal_length_error_px",
            np.array(focal_abs_errors, dtype=np.float32),
            store_full_data=store_full_data,
        ),
        GtsfmMetric(
            "focal_length_error_pct",
            np.array(focal_pct_errors, dtype=np.float32),
            store_full_data=store_full_data,
        ),
    ]
    if len(k1_errors) > 0:
        metrics.append(GtsfmMetric("k1_error", np.array(k1_errors, dtype=np.float32), store_full_data=store_full_data))
        metrics.append(GtsfmMetric("k2_error", np.array(k2_errors, dtype=np.float32), store_full_data=store_full_data))
    return GtsfmMetricsGroup(name="intrinsics_metrics", metrics=metrics)


def get_all_relative_rotations_translations(
    wTi: dict[int | str, Pose3],
) -> Tuple[dict[Tuple[int, int], Rot3], dict[Tuple[int, int], Unit3]]:
    """Compute measurements of *all* 2-view translation directions between image pairs.

    Args:
        wTi: Poses keyed by image id (e.g. could be ground truth).

    Returns:
        i2Ri1: Relative rotations keyed by (i1, i2).
        i2Ui1: Unit translation directions keyed by (i1, i2).
    """
    # check against all possible image pairs -- compute unit translation directions
    i2Ui1: dict[Tuple[int, int], Unit3] = {}
    i2Ri1: dict[Tuple[int, int], Rot3] = {}
    possible_img_pair_idxs = list(itertools.combinations(list(wTi.keys()), 2))
    for i1, i2 in possible_img_pair_idxs:
        assert wTi[i1] is not None and wTi[i2] is not None
        # compute the exact relative pose
        i2Ti1 = wTi[i2].between(wTi[i1])  # type: ignore
        direction = Unit3(i2Ti1.translation())
        rel_rot = i2Ti1.rotation()
        i2Ui1[(i1, i2)] = direction
        i2Ri1[(i1, i2)] = rel_rot
    return i2Ri1, i2Ui1


def get_precision_recall_from_errors(
    positive_errors: Sequence[Optional[float]], negative_errors: Sequence[Optional[float]], max_positive_error: float
) -> Tuple[float, float]:
    """Computes the precision and recall from a list of errors for positive and negative classes.
    True positives are those for which the error is less than max_positive_error.

    Args:
        positive_errors: List of errors for the predicted positive instances.
        negative_errors: List of errors for the predicted negative instances.
        max_positive_error: Maximum error for a true positive prediction.

    Returns:
        Tuple of precision, recall.
    """
    tp = np.sum(np.array(positive_errors, dtype=np.float32) <= max_positive_error)
    fp = np.sum(np.array(positive_errors, dtype=np.float32) > max_positive_error)
    fn = np.sum(np.array(negative_errors, dtype=np.float32) <= max_positive_error)

    eps = 1e-12  # prevent division by zero
    precision = tp * 1.0 / (tp + fp + eps)
    recall = tp * 1.0 / (tp + fn + eps)
    return float(precision), float(recall)


def get_rotations_translations_from_poses(
    poses: dict[int | str, Optional[Pose3]],
) -> Tuple[dict[int | str, Optional[Rot3]], dict[int | str, Optional[np.ndarray]]]:
    """Decompose each 6-dof pose to a 3-dof rotation and 3-dof position keyed by image id."""
    rotations = {k: v.rotation() if v is not None else None for k, v in poses.items()}
    translations = {k: v.translation() if v is not None else None for k, v in poses.items()}
    return rotations, translations


def save_metrics_as_json(metrics_groups: List[GtsfmMetricsGroup], output_dir: str) -> None:
    """Saves the input metrics groups as JSON files using the name of the group.

    Args:
        metrics_groups: List of GtsfmMetricsGroup to be saved.
        output_dir: Directory to save metrics to.
    """
    for metrics_group in metrics_groups:
        metrics_group.save_to_json(os.path.join(output_dir, metrics_group.name + ".json"))


def compute_percentage_change(x: float, y: float) -> float:
    """Return percentage in representing the regression or improvement of a value x, for new value y.

    Args:
        x: Original value to compare against.
        y: New value.

    Returns:
        Percentage change (may be positive or negative).
    """
    return (y - x) / (x + EPSILON) * 100


def get_measurement_angle_errors(
    i1_i2_pairs: Set[Tuple[int, int]],
    i2Ui1_measurements: dict[Tuple[int, int], Unit3],
    gt_i2Ui1_measurements: dict[Tuple[int, int], Unit3],
) -> List[float]:
    """Returns a list of the angle between i2Ui1_measurements and gt_i2Ui1_measurements for every
    (i1, i2) in i1_i2_pairs.

    Args:
        i1_i2_pairs: List of (i1, i2) tuples for which the angles must be computed.
        i2Ui1_measurements: Measured translation direction of i1 WRT i2.
        gt_i2Ui1_measurements: Ground truth translation direction of i1 WRT i2.

    Returns:
        List of angles between the measured and ground truth translation directions.
    """
    errors: List[float] = []
    for i1, i2 in i1_i2_pairs:
        if (i1, i2) in i2Ui1_measurements and (i1, i2) in gt_i2Ui1_measurements:
            error = comp_utils.compute_relative_unit_translation_angle(
                i2Ui1_measurements[(i1, i2)], gt_i2Ui1_measurements[(i1, i2)]
            )
            if error is None:
                raise ValueError("Unexpected `None` when computing relative translation angle metric.")
            errors.append(error)
    return errors


def pose_auc_from_poses(
    computed_wTis: dict[int, Pose3], ref_wTis: dict[int, Pose3], thresholds_deg: Sequence[float]
) -> Sequence[float]:
    """Computes area under the Recall (y) vs. Pose Error (x) curve, the pose AUC.

    If recall is defined as TP / # actual positives, then every camera is a TP if one can register it.

    Args:
        computed_wTis: list of poses for comparison, of length N.
        ref_wTis: references list of poses, of length N.
        thresholds: Angular error thresholds, in degrees.

    Returns:
        List of AUC values, one per threshold.
    """
    rotation_angular_errors = compute_rotation_angle_metric(
        wRi={i: wTi.rotation() for i, wTi in computed_wTis.items()},
        gt_wRi={i: wTi.rotation() for i, wTi in ref_wTis.items()},
        store_full_data=True,
    ).data
    translation_angular_errors = compute_translation_angle_metric(
        gt_wTi=ref_wTis,
        wTi=computed_wTis,
        store_full_data=True,
    ).data
    pose_angular_errors = np.maximum(rotation_angular_errors, translation_angular_errors)

    return pose_auc(pose_angular_errors, thresholds_deg)


def pose_auc(errors: np.ndarray, thresholds: Sequence[float], save_dir: Optional[str] = None) -> Sequence[float]:
    """Computes area under the Recall (y) vs. Pose Error (x) curve, the pose AUC.

    If recall is defined as TP / # actual positives, then every camera is a TP if one can register it.

    Args:
        errors: Array of shape (n,) representing angular errors.
        thresholds: Angular error thresholds.
        save_dir: Directory where AUC plots should be saved.

    Returns:
        List of AUC values, one per threshold.
    """
    errors = np.sort(errors)
    # Determine recall points, from [0,1].
    # Prepend `0` value to each array.
    recall = (np.arange(len(errors) + 1)) / len(errors)
    errors = np.array([0.0, *errors.tolist()])
    AUCs = []
    for t in thresholds:
        # Find indices where elements should be inserted to maintain order.
        last_index = np.searchsorted(errors, t)
        r = np.r_[recall[:last_index], recall[last_index - 1]]
        e = np.r_[errors[:last_index], t]
        if save_dir is not None:
            _ = plt.figure(dpi=200, facecolor="white")
            plt.style.use("ggplot")
            sns.set_style({"font.family": "DejaVu Serif"})
            plt.scatter(e, r, 20, color="k", marker=".")
            plt.plot(e, r, color="r")
            plt.ylabel("Recall")
            plt.xlabel("Pose Error (deg.)")
            uuid = datetime.datetime.utcnow().strftime("%Y_%m_%d_%H_%M_%S_%f")
            Path(save_dir, "plots", "pose_auc").mkdir(parents=True, exist_ok=True)
            save_fpath = Path(
                save_dir, "plots", "pose_auc", f"{uuid}_recall_vs_pose_error_curve_auc_{t}_deg_threshold.jpg"
            )
            plt.savefig(save_fpath)
            plt.close("all")

        # Integrate along the given axis using the composite trapezoidal rule.
        # As AUC = \int y(x) dx.
        auc_non_unit: float = np.trapezoid(y=r, x=e)
        # Divide by length of x-axis, as recall & precision usually would be [0,1],
        # but here x-axis (error) extends up to threshold `t`.
        auc_unit = auc_non_unit / t
        AUCs.append(auc_unit)
    return AUCs
